(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 3998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
;// CONCATENATED MODULE: ./config/color.ts
const colors = {
    brand: {
        purple: {
            100: "#D5CDFF",
            300: "#7971FF",
            500: "#34296B"
        },
        yellow: {
            100: "#FEF3AE",
            300: "#FDE85C",
            500: "#F3D400",
            700: "#FCD900"
        },
        green: {
            100: "rgba(29, 182, 188, 0.4)"
        },
        pink: {
            100: "#FFCED7",
            500: "#FF9CAE",
            700: "#E3719C"
        },
        white: "#FFFFFF",
        dark: {
            100: "#1A1A1A",
            200: "#121212",
            300: "#101828",
            400: "#4F4F4F"
        },
        gray: {
            10: "#D9D9D9",
            20: "#E4E4E4",
            50: "#5F6368",
            100: "#C4C4C4",
            200: "#969696",
            300: "#F6F7FD",
            400: "#707070",
            500: "#515151",
            600: "#787878",
            700: "#B4B4B4",
            800: "#414141",
            900: "#FBFBFB"
        },
        overlay: {
            100: "linear-gradient(90deg, rgba(59, 27, 108, 0.5) 3.28%, rgba(0, 0, 0, 0.4) 42.94%, rgba(59, 27, 108, 0.5) 93.23%)",
            200: "rgba(0, 0, 0, 0.17)",
            300: "rgba(0, 0, 0, 0.7)"
        }
    }
};

;// CONCATENATED MODULE: ./config/components/Button.ts
const Button = {
    baseStyle: {
        bg: "#34296B",
        fontWeight: "700",
        fontSize: [
            "0.853rem",
            "0.853rem",
            "xl"
        ],
        borderRadius: "10px",
        color: "brand.white",
        px: [
            "1.5rem",
            "1.5rem",
            "2.25rem"
        ],
        py: "0.875rem",
        _hover: {
            bg: "brand.yellow.700",
            color: "brand.purple.500",
            borderTopRightRadius: "10px",
            borderBottomLeftRadius: "10px"
        }
    },
    sizes: {
        sm: {
            fontSize: "md",
            height: "34px"
        },
        lg: {
            fontSize: "2xl",
            height: "73px"
        }
    },
    variants: {
        link: {
            padding: 0,
            color: "brand.purple.500",
            fontWeight: "700",
            fontSize: "1.125rem",
            backgroundColor: "transparent",
            _hover: {
                textDecoration: "none",
                border: "none",
                backgroundColor: "transparent",
                color: "brand.yellow.700"
            }
        },
        solid: {
            bg: "brand.purple.500",
            fontWeight: "700",
            fontSize: [
                "0.853rem",
                "0.853rem",
                "xl"
            ],
            borderRadius: "10px",
            color: "brand.white",
            px: "2.25rem",
            py: "0.875rem",
            transition: "all 0.35s ease-in-out",
            _hover: {
                bg: "brand.yellow.700",
                color: "brand.purple.500",
                borderTopRightRadius: "10px",
                borderBottomLeftRadius: "10px",
                borderTopLeftRadius: "0",
                borderBottomRightRadius: "0"
            }
        },
        "solid-white": {
            bg: "brand.white",
            color: "brand.purple.500",
            fontWeight: "700",
            transition: "all 0.35s ease-in-out",
            _hover: {
                bg: "brand.yellow.700",
                color: "brand.purple.500",
                borderTopRightRadius: "10px",
                borderBottomLeftRadius: "10px",
                borderTopLeftRadius: "0",
                borderBottomRightRadius: "0"
            }
        },
        "rounded-solid": {
            bg: "brand.white",
            fontWeight: "700",
            fontSize: [
                "0.853rem",
                "0.853rem",
                "xl"
            ],
            borderRadius: "30px",
            color: "brand.purple.500",
            px: "2.25rem",
            py: "0.875rem",
            transition: "all 0.35s ease-in-out",
            _hover: {
                borderRadius: "30px",
                bg: "brand.yellow.700"
            }
        },
        outline: {
            bg: "transparent",
            color: "brand.purple.500",
            borderColor: "brand.purple.500",
            _hover: {
                bg: "brand.purple.500",
                color: "brand.white"
            }
        },
        "rounded-solid-yellow-with-outline": {
            bg: "brand.yellow.700",
            fontWeight: "700",
            fontSize: [
                "0.853rem",
                "0.853rem",
                "xl"
            ],
            borderRadius: "30px",
            color: "brand.purple.500",
            px: "6.875rem",
            py: "1.75rem",
            transition: "all 0.35s ease-in-out",
            position: "relative",
            _hover: {
                borderRadius: "30px"
            },
            _before: {
                content: '""',
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: "calc(100% + 10px)",
                height: "calc(100% + 10px)",
                borderRadius: "30px",
                borderWidth: "1px",
                borderColor: "#F3F3F3"
            }
        },
        subtle: (props)=>{
            return {
                backgroundColor: `${props.colorScheme}.50`,
                color: `${props.colorScheme}.700`
            };
        }
    }
};

;// CONCATENATED MODULE: ./config/theme.ts



const theme = (0,react_.extendTheme)({
    styles: {
        global: {
            body: {
                bg: "brand.white",
                color: "brand.purple.500",
                fontSize: "1rem"
            },
            a: {
                color: "brand.purple.500"
            },
            button: {
                _focus: {
                    outline: "none"
                }
            },
            "h1, h2, h3, h4, h5, h6": {
                color: "brand.purple.500",
                fontWeight: "700"
            },
            ".nested-scope-list": {
                ol: {
                    counterReset: "item"
                },
                "li > ul": {
                    paddingLeft: "30px"
                },
                "ol > li": {
                    display: "block",
                    indentStyle: "inherit"
                },
                "ol > li:before": {
                    content: `counters(item, ". ") ". "`,
                    counterIncrement: "item"
                }
            }
        }
    },
    fonts: {
        body: "Proxima Nova, sans-serif",
        heading: "Proxima Nova, sans-serif",
        inter: "Inter, sans-serif"
    },
    colors: colors,
    sizes: {
        gutter: {
            sm: "10px",
            md: "20px"
        }
    },
    fontSizes: {
        xs: "0.75rem",
        sm: "0.8rem",
        md: "0.875rem",
        lg: "1rem",
        xl: "1.125rem",
        "2xl": "1.25rem",
        "3xl": "1.5rem",
        "4xl": "1.875rem",
        "5xl": "1.923rem",
        "6xl": "2.084rem",
        "7xl": "3.125rem",
        "8xl": "3.75rem",
        "9xl": "4.375rem",
        "1xxl": "5.168rem",
        "2xxl": "4rem"
    },
    components: {
        Button: Button
    }
});

// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick.css
var slick = __webpack_require__(8278);
// EXTERNAL MODULE: ./node_modules/slick-carousel/slick/slick-theme.css
var slick_theme = __webpack_require__(782);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./state/store.ts
var store = __webpack_require__(8857);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./pages/_app.tsx










function App({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_redux_.Provider, {
        store: store/* store */.h,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "theme-color",
                        content: "#34296B"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "title",
                        content: "Perxels Design School"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:type",
                        content: "website"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:url",
                        content: "https://perxels.com/"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: "Perxels Design School"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "twitter:card",
                        content: "summary_large_image"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "twitter:url",
                        content: "https://perxels.com/"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "twitter:title",
                        content: "Perxels Design School"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "twitter:description",
                        content: "With the aid of an experienced mentor and professionals, we provide design education to aspiring UI/UX designers and also help designers grow to expertise level by exposing them to real-life cases."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "twitter:image",
                        content: "https://res.cloudinary.com/dmwfd0zhh/image/upload/v1599151361/perxels/Main%20Images/perxels_v7pzod.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1, maximum-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Perxels - Design School"
                    }, "title")
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "afterInteractive",
                src: "https://www.googletagmanager.com/gtag/js?id=UA-176409924-1"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "afterInteractive",
                id: "google-analytics",
                dangerouslySetInnerHTML: {
                    __html: `
        window.dataLayer = window.dataLayer || [];
        function gtag() {
          dataLayer.push(arguments);
        }
        gtag("js", new Date());
  
        gtag("config", "UA-176409924-1");
        `
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "afterInteractive",
                id: "facebook-pixel",
                dangerouslySetInnerHTML: {
                    __html: `
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window,document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
         fbq('init', '821337219169131'); 
        fbq('track', 'PageView');
        `
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("noscript", {
                dangerouslySetInnerHTML: {
                    __html: `
        <img height="1" width="1" 
        src="https://www.facebook.com/tr?id=821337219169131&ev=PageView
        &noscript=1"/>
        `
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "afterInteractive",
                id: "twitter-universal",
                dangerouslySetInnerHTML: {
                    __html: `!function(e,t,n,s,u,a){e.twq||(s=e.twq=function(){s.exe?s.exe.apply(s,arguments):s.queue.push(arguments);
        },s.version='1.1',s.queue=[],u=t.createElement(n),u.async=!0,u.src='//static.ads-twitter.com/uwt.js',
        a=t.getElementsByTagName(n)[0],a.parentNode.insertBefore(u,a))}(window,document,'script');
        // Insert Twitter Pixel ID and Standard Event data below
        twq('init','o62eq');
        twq('track','PageView');`
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.ChakraProvider, {
                theme: theme,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
}


/***/ }),

/***/ 782:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports =
   false
    ? 0
    : __webpack_require__(3573)


/***/ }),

/***/ 8930:
/***/ ((module) => {

"use strict";
module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [573,230,857], () => (__webpack_exec__(3998)));
module.exports = __webpack_exports__;

})();