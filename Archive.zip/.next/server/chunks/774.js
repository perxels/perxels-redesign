"use strict";
exports.id = 774;
exports.ids = [774];
exports.modules = {

/***/ 5691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ ClassDetails)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__);





// added class details props
const ClassDetails = ({ title , classDur , classTime , classType , installments , tuition , courseOutline , id  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.SimpleGrid, {
        id: id,
        columns: [
            1,
            1,
            1,
            12
        ],
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.GridItem, {
                colSpan: [
                    1,
                    1,
                    1,
                    4
                ],
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        px: [
                            "0.75rem",
                            "0.75rem",
                            "0.75rem",
                            "1.875rem"
                        ],
                        py: "1.5rem",
                        bg: "brand.pink.700",
                        roundedTopLeft: "8px",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                            as: "span",
                            fontSize: [
                                "2rem",
                                "2rem",
                                "2rem",
                                "2.8rem"
                            ],
                            color: "white",
                            pos: "relative",
                            children: [
                                title,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Img, {
                                    pos: "absolute",
                                    top: [
                                        "-8px",
                                        "-8px",
                                        "-8px",
                                        "0"
                                    ],
                                    right: "-2rem",
                                    src: "/assets/icons/class-icon.svg"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        px: [
                            ".75rem",
                            ".75rem",
                            ".75rem",
                            "1.875rem"
                        ],
                        py: "1.5rem",
                        pb: "2.3rem",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.SimpleGrid, {
                                columns: [
                                    2,
                                    2,
                                    2,
                                    1
                                ],
                                spacing: [
                                    ".75rem",
                                    ".75rem",
                                    ".75rem",
                                    "1.85rem"
                                ],
                                w: "full",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.VStack, {
                                        spacing: "5px",
                                        w: "full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                w: "full",
                                                fontSize: [
                                                    "lg",
                                                    "lg",
                                                    "lg",
                                                    "2xl"
                                                ],
                                                color: "brand.gray.200",
                                                children: "Course Duration:"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                                color: "brand.dark.200",
                                                textTransform: "uppercase",
                                                w: "full",
                                                fontSize: [
                                                    "lg",
                                                    "lg",
                                                    "lg",
                                                    "2xl"
                                                ],
                                                children: classDur
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.VStack, {
                                        spacing: "5px",
                                        w: "full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                w: "full",
                                                fontSize: [
                                                    "lg",
                                                    "lg",
                                                    "lg",
                                                    "2xl"
                                                ],
                                                color: "brand.gray.200",
                                                children: "Class times:"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                                color: "brand.dark.200",
                                                textTransform: "uppercase",
                                                w: "full",
                                                fontSize: [
                                                    "lg",
                                                    "lg",
                                                    "lg",
                                                    "2xl"
                                                ],
                                                children: classTime
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.VStack, {
                                        spacing: "5px",
                                        w: "full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                w: "full",
                                                fontSize: [
                                                    "lg",
                                                    "lg",
                                                    "lg",
                                                    "2xl"
                                                ],
                                                color: "brand.gray.200",
                                                children: "Class Type:"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                                color: "brand.dark.200",
                                                textTransform: "uppercase",
                                                w: "full",
                                                fontSize: [
                                                    "lg",
                                                    "lg",
                                                    "lg",
                                                    "2xl"
                                                ],
                                                pr: [
                                                    "1rem",
                                                    "5rem"
                                                ],
                                                children: classType
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.VStack, {
                                        spacing: "5px",
                                        w: "full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                w: "full",
                                                fontSize: [
                                                    "lg",
                                                    "lg",
                                                    "lg",
                                                    "2xl"
                                                ],
                                                color: "brand.gray.200",
                                                children: "Installments:"
                                            }),
                                            installments.map((installment)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                                    color: "brand.dark.200",
                                                    textTransform: "uppercase",
                                                    w: "full",
                                                    fontSize: [
                                                        "lg",
                                                        "lg",
                                                        "lg",
                                                        "2xl"
                                                    ],
                                                    children: installment
                                                }, installment))
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.GridItem, {
                                        colSpan: [
                                            2,
                                            2,
                                            2,
                                            1
                                        ],
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.VStack, {
                                            spacing: "5px",
                                            w: "full",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                    w: "full",
                                                    fontSize: [
                                                        "lg",
                                                        "lg",
                                                        "lg",
                                                        "2xl"
                                                    ],
                                                    color: "brand.gray.200",
                                                    children: "Tuition:"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                                    w: "full",
                                                    fontSize: [
                                                        "6xl",
                                                        "6xl",
                                                        "7xl"
                                                    ],
                                                    children: tuition
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                mt: "2.188rem",
                                size: "lg",
                                px: "4.375rem",
                                py: "1.5rem",
                                fontSize: "2xl",
                                display: [
                                    "none",
                                    "none",
                                    "none",
                                    "block"
                                ],
                                as: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                                href: "/enrol",
                                children: "Enroll For This Plan"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.GridItem, {
                colSpan: [
                    1,
                    1,
                    1,
                    8
                ],
                bg: "brand.gray.300",
                px: [
                    ".75rem",
                    ".75rem",
                    ".75rem",
                    "3.5rem"
                ],
                py: [
                    "2.5rem",
                    "2.5rem",
                    "2.5rem",
                    "3.75rem"
                ],
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.List, {
                        spacing: "1.875rem",
                        children: courseOutline.map((outline)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                templateColumns: [
                                    "1.5rem 1fr",
                                    "1.5rem 1fr",
                                    "1.5rem 1fr",
                                    "30px 1fr"
                                ],
                                gap: [
                                    "0.75rem",
                                    "1.125rem"
                                ],
                                alignItems: "center",
                                fontSize: [
                                    "lg",
                                    "lg",
                                    "lg",
                                    "2xl"
                                ],
                                color: "brand.dark.200",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.ListIcon, {
                                        as: react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsFillCheckCircleFill,
                                        fontSize: [
                                            "1.5rem",
                                            "1.5rem",
                                            "1.5rem",
                                            "1.875rem"
                                        ],
                                        color: "brand.purple.500"
                                    }),
                                    outline
                                ]
                            }, outline))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Center, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                            mt: "2.188rem",
                            size: "lg",
                            px: "4.375rem",
                            py: "1.5rem",
                            fontSize: "2xl",
                            display: [
                                "block",
                                "block",
                                "block",
                                "none"
                            ],
                            as: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                            href: "/enrol",
                            children: "Enroll For This Plan"
                        })
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 8774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "d9": () => (/* reexport */ ClassLists),
  "VM": () => (/* reexport */ Hero),
  "$M": () => (/* reexport */ LeaningTools),
  "H3": () => (/* reexport */ OurClassGroup),
  "hN": () => (/* reexport */ StudentWorkWrapper)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/index.ts + 9 modules
var components = __webpack_require__(6520);
// EXTERNAL MODULE: ./constant/index.ts + 9 modules
var constant = __webpack_require__(230);
// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./features/classGroup/ClassCard.tsx




const ClassCard = ({ title , content , image , link  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
        flexDir: "column",
        justifyContent: "flex-end",
        width: "full",
        h: [
            "410.39px",
            "410.39px",
            "541px"
        ],
        bg: `linear-gradient(360deg, #000000 23.68%, rgba(0, 0, 0, 0) 106.41%), url(${image}) center/cover no-repeat`,
        borderRadius: "18px",
        overflow: "hidden",
        px: "2rem",
        py: "2.75rem",
        className: "class-group-card",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                color: "brand.white",
                fontSize: [
                    "3xl",
                    "4xl",
                    "4xl",
                    "6xl"
                ],
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                color: "brand.white",
                fontSize: [
                    "xs",
                    "sm",
                    "md",
                    "xl"
                ],
                children: content
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                as: (link_default()),
                href: link,
                _hover: {
                    textDecoration: "none"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                    mt: "2.5rem",
                    w: {
                        base: "170px",
                        lg: "212px"
                    },
                    variant: "solid-white",
                    children: "View Details"
                })
            })
        ]
    });
};

// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(4287);
var external_gsap_default = /*#__PURE__*/__webpack_require__.n(external_gsap_);
// EXTERNAL MODULE: external "gsap/dist/ScrollTrigger"
var ScrollTrigger_ = __webpack_require__(4965);
var ScrollTrigger_default = /*#__PURE__*/__webpack_require__.n(ScrollTrigger_);
;// CONCATENATED MODULE: ./features/classGroup/OurClassGroup.tsx









external_gsap_default().registerPlugin((ScrollTrigger_default()));
const OurClassGroup = ({ title  })=>{
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            external_gsap_default().from(".class-group-card", {
                opacity: "0",
                y: 200,
                duration: 1,
                delay: 1,
                scrollTrigger: {
                    trigger: ".class-group-wrapper",
                    start: "-900 top",
                    end: "bottom bottom"
                },
                stagger: 1
            });
        });
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        mt: [
            "3.75rem",
            "3.75rem",
            "7.5rem"
        ],
        className: "class-group-wrapper",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layouts/* MainContainer */.t, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                    subTitle: title || "Our CLass Groups",
                    title: "Here At Perxels,",
                    paragraph: "Our class groups are designed to accommodate your current level of design and unique learning process."
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.SimpleGrid, {
                    mb: [
                        "3.75rem",
                        "3.75rem",
                        "7rem"
                    ],
                    columns: [
                        1,
                        1,
                        2
                    ],
                    spacing: "1rem",
                    children: constant/* ClassGroupContent.map */.P1.map(({ title , content , image , link  })=>/*#__PURE__*/ jsx_runtime_.jsx(ClassCard, {
                            link: link,
                            title: title,
                            content: content,
                            image: image
                        }, title))
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./features/classGroup/ClassDetails.tsx
var ClassDetails = __webpack_require__(5691);
;// CONCATENATED MODULE: ./features/classGroup/ClassLists.tsx






const ClassLists = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        py: "3.75rem",
        children: /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.VStack, {
                spacing: "3.75rem",
                children: constant/* classGroupDetails.map */.um.map(({ id , title , classDur , classTime , classType , installments , tuition , courseOutline  })=>/*#__PURE__*/ jsx_runtime_.jsx(ClassDetails/* ClassDetails */.e, {
                        id: id,
                        title: title,
                        classDur: classDur,
                        classTime: classTime,
                        installments: installments,
                        tuition: tuition,
                        courseOutline: courseOutline,
                        classType: classType
                    }, id))
            })
        })
    });
};

// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
;// CONCATENATED MODULE: ./features/classGroup/StudentWorkCard.tsx




const StudentWorkCard = ({ imgUrl , link  })=>{
    const [isHover, setIsHover] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        onMouseEnter: ()=>setIsHover(true),
        onMouseLeave: ()=>setIsHover(false),
        pos: "relative",
        rounded: "8px",
        overflow: "hidden",
        as: react_.Link,
        href: link,
        children: [
            isHover && /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                pos: "absolute",
                top: "0",
                left: "0",
                w: "full",
                h: "full",
                bg: "brand.overlay.300",
                rounded: "5px",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.HStack, {
                    alignItems: "center",
                    cursor: "pointer",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                            as: ai_.AiOutlineLink,
                            fontSize: "2.5rem",
                            color: "brand.white"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                            fontSize: "2xl",
                            color: "brand.white",
                            children: "View Case Study"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                src: imgUrl,
                alt: "student work",
                w: "100%",
                h: "auto"
            })
        ]
    }, imgUrl);
};
/* harmony default export */ const classGroup_StudentWorkCard = (StudentWorkCard);

;// CONCATENATED MODULE: ./features/classGroup/StudentWorkWrapper.tsx







const StudentWorkWrapper = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        bg: "brand.purple.500",
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
            bg: `url(./assets/images/class-group/class-group-bg.png) center/cover no-repeat`,
            children: /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
                bg: "none",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                    py: "5.75rem",
                    pos: "relative",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                            title: "See Our Students’ work",
                            subTitle: "Students’ portfolio",
                            isWhite: true,
                            isArrow: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                            src: "/assets/icons/arrow-right-up.svg",
                            pos: "absolute",
                            width: "12rem",
                            height: "auto",
                            bottom: "-3rem",
                            right: "0",
                            display: [
                                "none",
                                "none",
                                "none",
                                "block"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.SimpleGrid, {
                            pt: [
                                "1rem",
                                "1rem",
                                "1rem",
                                "2.5rem"
                            ],
                            columns: [
                                1,
                                1,
                                1,
                                2
                            ],
                            gap: [
                                "1.25rem",
                                "1.25rem",
                                "1.25rem",
                                "3.75rem"
                            ],
                            children: constant/* StudentWorks.map */.k2.map(({ imgUrl , link  })=>/*#__PURE__*/ jsx_runtime_.jsx(classGroup_StudentWorkCard, {
                                    imgUrl: imgUrl,
                                    link: link
                                }, imgUrl))
                        })
                    ]
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./features/classGroup/LeaningTools.tsx





const LeaningTools = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
            w: "full",
            py: "6.375rem",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                    title: "Learn with the industry’s best tools",
                    subTitle: "Learning tools",
                    paragraph: "We are proud to see our students getting design jobs, impacting product teams with their skills and being paid well for their value.",
                    isArrow: true,
                    arrowTopPos: "3rem",
                    arrowRightBottomPos: "1rem",
                    arrowRightPos: "3rem"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
                    columns: [
                        1,
                        1,
                        2,
                        3
                    ],
                    spacing: "2.5rem",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "full",
                            h: "147px",
                            bg: "brand.white",
                            shadow: "0px 7px 53px rgba(75, 75, 75, 0.06)",
                            rounded: "5px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                w: "162px",
                                h: "auto",
                                src: "/assets/icons/figma.svg",
                                alt: "figma"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "full",
                            h: "147px",
                            bg: "brand.white",
                            shadow: "0px 7px 53px rgba(75, 75, 75, 0.06)",
                            rounded: "5px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                w: "187px",
                                h: "auto",
                                src: "/assets/icons/figjam.svg",
                                alt: "figjam"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "full",
                            h: "147px",
                            bg: "brand.white",
                            shadow: "0px 7px 53px rgba(75, 75, 75, 0.06)",
                            rounded: "5px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                w: "154px",
                                h: "auto",
                                src: "/assets/icons/miro.svg",
                                alt: "miro"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "full",
                            h: "147px",
                            bg: "brand.white",
                            shadow: "0px 7px 53px rgba(75, 75, 75, 0.06)",
                            rounded: "5px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                w: "312.9px",
                                h: "auto",
                                src: "/assets/icons/meet.svg",
                                alt: "google meet"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "full",
                            h: "147px",
                            bg: "brand.white",
                            shadow: "0px 7px 53px rgba(75, 75, 75, 0.06)",
                            rounded: "5px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                w: "290.07px",
                                h: "auto",
                                src: "/assets/icons/g-form.svg",
                                alt: "google form"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "full",
                            h: "147px",
                            bg: "brand.white",
                            shadow: "0px 7px 53px rgba(75, 75, 75, 0.06)",
                            rounded: "5px",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                w: "242px",
                                h: "auto",
                                src: "/assets/icons/illustrator.svg",
                                alt: "adobe illustrator"
                            })
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./features/classGroup/Hero.tsx





const Hero = ()=>{
    const mainRef = (0,external_react_.useRef)(null);
    const videoRef = (0,external_react_.useRef)(null);
    const tl = (0,external_react_.useRef)(external_gsap_default().timeline({
        paused: true
    }));
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            tl.current.from(".arrow-erica", {
                opacity: 0,
                y: 100,
                duration: 0.5,
                delay: 0.5
            }).from(".class-plan-title", {
                opacity: 0,
                y: 100,
                duration: 0.5
            }).from(".class-plan-heading", {
                opacity: 0,
                y: 100,
                duration: 0.5
            }).from(".class-plan-trained", {
                opacity: 0,
                y: 100,
                duration: 1
            }).from(".class-plan-thousand", {
                opacity: 0,
                y: 100,
                duration: 1
            }).from(".arrow-mhiz", {
                opacity: 0,
                y: 100,
                duration: 1
            }).play();
            external_gsap_default().from(".class-plan-video", {
                opacity: 0,
                scale: 0,
                duration: 1,
                delay: 1
            });
        }, mainRef);
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: mainRef,
        w: "full",
        bg: `url(./assets/images/heroBg.png) center/cover no-repeat`,
        children: /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
            bg: "none",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
                py: "2.5rem",
                columns: [
                    1,
                    1,
                    1,
                    12
                ],
                spacing: "2.5rem",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.GridItem, {
                        h: "full",
                        colSpan: [
                            1,
                            1,
                            1,
                            5
                        ],
                        pt: [
                            "3rem",
                            "3rem",
                            "3rem",
                            0
                        ],
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                            pos: "relative",
                            h: "full",
                            flexDir: "column",
                            justifyContent: "center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                    src: "/assets/icons/arrow_erica.svg",
                                    width: "157px",
                                    height: "auto",
                                    pos: "absolute",
                                    right: "2rem",
                                    top: "5rem",
                                    display: [
                                        "none",
                                        "none",
                                        "none",
                                        "block"
                                    ],
                                    className: "arrow-erica"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                    src: "/assets/icons/arrow_mhiz.svg",
                                    width: "157px",
                                    height: "auto",
                                    pos: "absolute",
                                    right: "8rem",
                                    top: "21rem",
                                    display: [
                                        "none",
                                        "none",
                                        "none",
                                        "block"
                                    ],
                                    className: "arrow-mhiz",
                                    zIndex: "4"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    w: "full",
                                    fontSize: [
                                        "lg",
                                        "lg",
                                        "xl"
                                    ],
                                    fontWeight: "600",
                                    textTransform: "uppercase",
                                    className: "class-plan-title",
                                    children: "Enroll Page"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    maxW: "505px",
                                    fontSize: [
                                        "3rem",
                                        "3rem",
                                        "3.5rem"
                                    ],
                                    fontWeight: "black",
                                    lineHeight: 1.15,
                                    className: "class-plan-heading",
                                    children: "Building Top Designers for the World."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    w: "full",
                                    fontSize: [
                                        "lg",
                                        "lg",
                                        "xl"
                                    ],
                                    pt: "1.5rem",
                                    fontWeight: "600",
                                    textTransform: "uppercase",
                                    className: "class-plan-trained",
                                    children: "TRAINED"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                    w: "full",
                                    fontSize: [
                                        "5.625rem",
                                        "5.625rem",
                                        "7.5rem"
                                    ],
                                    lineHeight: 1.2,
                                    color: "brand.purple.300",
                                    fontWeight: "black",
                                    className: "class-plan-thousand",
                                    children: "3000+"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.GridItem, {
                        h: "full",
                        colSpan: [
                            1,
                            1,
                            1,
                            7
                        ],
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                            roundedLeft: "10px",
                            overflow: "hidden",
                            mr: [
                                "0",
                                "0",
                                "0",
                                "0",
                                "-6rem",
                                "0"
                            ],
                            pos: "relative",
                            className: "class-plan-video",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                ref: videoRef,
                                width: "100%",
                                height: "auto",
                                src: "https://res.cloudinary.com/dhqvopvj4/image/upload/v1673023991/perxels/enrol_jabfce.gif"
                            })
                        })
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./features/classGroup/index.ts







/***/ })

};
;