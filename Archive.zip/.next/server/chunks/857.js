"use strict";
exports.id = 857;
exports.ids = [857];
exports.modules = {

/***/ 9572:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Le": () => (/* binding */ setSelectedTestimonial),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "bw": () => (/* binding */ setTestimonials)
/* harmony export */ });
/* unused harmony exports testimonialSlice, setSelectedTestimonialIndex */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(230);


const initialState = {
    selectedTestimonial: _constant__WEBPACK_IMPORTED_MODULE_1__/* .testimonialSliderContent[0] */ .qV[0],
    selectedTestimonialIndex: 1,
    testimonials: _constant__WEBPACK_IMPORTED_MODULE_1__/* .testimonialSliderContent */ .qV
};
const testimonialSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "testimonial",
    initialState,
    reducers: {
        setSelectedTestimonial: (state, action)=>{
            state.selectedTestimonial = action.payload;
        },
        setSelectedTestimonialIndex: (state, action)=>{
            state.selectedTestimonialIndex = action.payload;
        },
        setTestimonials: (state, action)=>{
            state.testimonials = action.payload;
        }
    }
});
const { setSelectedTestimonial , setSelectedTestimonialIndex , setTestimonials  } = testimonialSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (testimonialSlice.reducer);


/***/ }),

/***/ 8857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CG": () => (/* binding */ useAppSelector),
/* harmony export */   "TL": () => (/* binding */ useAppDispatch),
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _features_TestimonialSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9572);



const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        testimonial: _features_TestimonialSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP
    }
});
const useAppDispatch = react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch;
const useAppSelector = react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector;


/***/ })

};
;