"use strict";
exports.id = 862;
exports.ids = [862];
exports.modules = {

/***/ 4862:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "n_": () => (/* reexport */ ClassPlan),
  "td": () => (/* reexport */ Instructions),
  "Ro": () => (/* reexport */ SponsorHero),
  "gc": () => (/* reexport */ Testimonial)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: ./components/index.ts + 9 modules
var components = __webpack_require__(6520);
// EXTERNAL MODULE: ./constant/index.ts + 9 modules
var constant = __webpack_require__(230);
// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
;// CONCATENATED MODULE: ./features/sponsorship/Instructions.tsx







const Instructions = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        bg: "brand.purple.500",
        backgroundImage: "url('/assets/images/hire/bgPatternPurple.png')",
        backgroundRepeat: "repeat",
        backgroundSize: "cover",
        children: /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
            bg: "none",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                py: [
                    "3rem",
                    "3rem",
                    "3rem",
                    "4.875rem"
                ],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                        title: "Read the following information before applying.",
                        subTitle: "Instructions",
                        isWhite: true,
                        maxW: "936px",
                        headingSize: [
                            "1.75rem",
                            "1.75rem",
                            "1.75rem",
                            "7xl"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
                        mt: [
                            "3rem",
                            "3rem",
                            "3rem",
                            "6rem"
                        ],
                        mb: "1rem",
                        alignItems: "center",
                        columns: [
                            1,
                            1,
                            1,
                            2
                        ],
                        gap: [
                            "0.5rem",
                            "0.5rem",
                            "0.5rem",
                            "4rem"
                        ],
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.GridItem, {
                                pos: [
                                    "static",
                                    "static",
                                    "static",
                                    "relative"
                                ],
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                        src: "./assets/images/sponsorship/instruction.png",
                                        alt: "Instructions",
                                        w: "950px",
                                        maxW: "950px",
                                        h: "auto",
                                        display: [
                                            "none",
                                            "none",
                                            "none",
                                            "block"
                                        ],
                                        pos: [
                                            "static",
                                            "static",
                                            "static",
                                            "absolute"
                                        ],
                                        left: [
                                            "auto",
                                            "auto",
                                            "auto",
                                            "-20rem"
                                        ],
                                        top: "50%",
                                        transform: "translateY(-45%)"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                        src: "./assets/images/sponsorship/instruction-mobile.png",
                                        alt: "Instructions",
                                        display: [
                                            "block",
                                            "block",
                                            "block",
                                            "none"
                                        ],
                                        w: "full",
                                        h: "auto"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.GridItem, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.SimpleGrid, {
                                    columns: [
                                        1,
                                        1,
                                        1,
                                        2
                                    ],
                                    gap: "3rem",
                                    children: constant/* instructions.map */.NE.map(({ id , title , description , image  })=>/*#__PURE__*/ jsx_runtime_.jsx(react_.GridItem, {
                                            w: "full",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Grid, {
                                                gap: "1rem",
                                                templateColumns: "1.5rem 1fr",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                                        as: bs_.BsCheckCircle,
                                                        color: "brand.white",
                                                        fontSize: "1.5rem"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                                                color: "brand.white",
                                                                fontSize: [
                                                                    "2xl",
                                                                    "2xl",
                                                                    "2xl",
                                                                    "xl"
                                                                ],
                                                                children: title
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                                maxW: [
                                                                    "full",
                                                                    "full",
                                                                    "full",
                                                                    "230px"
                                                                ],
                                                                color: "brand.white",
                                                                fontSize: [
                                                                    "lg"
                                                                ],
                                                                mt: "1rem",
                                                                children: description
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }, id))
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: external "react-icons/io"
var io_ = __webpack_require__(4751);
;// CONCATENATED MODULE: ./features/sponsorship/SponsorHero.tsx





const SponsorHero = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
            py: [
                "3rem",
                "3rem",
                "3rem",
                "0",
                "0"
            ],
            columns: [
                1,
                1,
                1,
                2
            ],
            gap: "3rem",
            w: "full",
            h: [
                "auto",
                "auto",
                "auto",
                "auto",
                "100vh"
            ],
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                    flexDir: "column",
                    justifyContent: "center",
                    w: "full",
                    h: "full",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.HStack, {
                            as: "span",
                            w: "auto",
                            maxW: [
                                "260px",
                                "300px",
                                "300px",
                                "362px"
                            ],
                            bg: "brand.purple.100",
                            p: "4px",
                            rounded: "1rem",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                    fontSize: [
                                        "0.65rem",
                                        "sm",
                                        "sm",
                                        "lg"
                                    ],
                                    fontWeight: "500",
                                    as: "span",
                                    bg: "brand.white",
                                    rounded: "1rem",
                                    px: "10px",
                                    py: "2px",
                                    children: "We’re sponsoring!"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.HStack, {
                                    spacing: "4px",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                            fontSize: [
                                                "0.65rem",
                                                "sm",
                                                "sm",
                                                "lg"
                                            ],
                                            fontWeight: "500",
                                            as: "span",
                                            px: "10px",
                                            py: "2px",
                                            children: "Join our design class"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                            as: io_.IoMdArrowForward
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                            fontSize: [
                                "6xl",
                                "6xl",
                                "6xl",
                                "8xl"
                            ],
                            fontWeight: "700",
                            mt: "1.25rem",
                            color: "brand.dark.300",
                            children: "Get 20% Off from October Cohort Tuition Fee."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                            fontSize: [
                                "lg",
                                "lg",
                                "lg",
                                "xl"
                            ],
                            color: "brand.dark.200",
                            maxW: "500px",
                            mt: "1.25rem",
                            children: "100 undergraduates will receive 50% scholarship and 100 professionals will receive 25% scholarship. 100 undergraduates will receive 50% scholarship."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            h: "3.125rem",
                            px: "3.875rem",
                            maxW: "212px",
                            mt: "2rem",
                            children: "Apply Now"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                    pos: "relative",
                    mb: [
                        "2rem",
                        "2rem",
                        "2rem",
                        "0"
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                        src: "./assets/images/sponsorship/sponsorHero.png",
                        alt: "sponsor hero",
                        w: "full",
                        h: "auto",
                        pos: [
                            "static",
                            "static",
                            "static",
                            "absolute"
                        ],
                        right: "-6rem"
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./features/classGroup/index.ts + 7 modules
var classGroup = __webpack_require__(8774);
;// CONCATENATED MODULE: ./features/sponsorship/ClassPlan.tsx





const ClassPlan = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        my: "3.625rem",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                subTitle: "Class Plans",
                title: "Choose from any of these Class Plans."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(classGroup/* ClassLists */.d9, {})
        ]
    });
};

// EXTERNAL MODULE: ./features/testimonial/index.ts + 3 modules
var testimonial = __webpack_require__(3976);
;// CONCATENATED MODULE: ./features/sponsorship/Testimonial.tsx







const Testimonial = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
            my: "3.625rem",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                    subTitle: "Testimonials",
                    title: "Our Students are getting jobs 100%"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(testimonial/* TestimonialGrid */.WB, {
                    testimonialContent: constant/* testimonialContent */.to
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./features/sponsorship/index.ts






/***/ })

};
;