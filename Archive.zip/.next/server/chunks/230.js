"use strict";
exports.id = 230;
exports.ids = [230];
exports.modules = {

/***/ 230:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "P1": () => (/* reexport */ ClassGroupContent),
  "hA": () => (/* reexport */ FooterSocialLinks),
  "k2": () => (/* reexport */ StudentWorks),
  "Gj": () => (/* reexport */ bannerContent),
  "um": () => (/* reexport */ classGroupDetails),
  "v5": () => (/* reexport */ hireCardContent),
  "NE": () => (/* reexport */ instructions),
  "Ok": () => (/* reexport */ links),
  "ZI": () => (/* reexport */ marketPlaceContent),
  "to": () => (/* reexport */ testimonialContent),
  "gW": () => (/* reexport */ testimonialContentSecond),
  "qV": () => (/* reexport */ testimonialSliderContent)
});

// UNUSED EXPORTS: workDetails

// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./constant/footerContent.tsx


const FooterSocialLinks = [
    {
        name: "Twitter",
        url: "https://twitter.com/perxels",
        icon: fa_.FaTwitter
    },
    {
        name: "Instagram",
        url: "https://www.instagram.com/perxels/",
        icon: ai_.AiFillInstagram
    },
    {
        name: "LinkedIn",
        url: "https://www.linkedin.com/company/perxels/",
        icon: fa_.FaLinkedin
    },
    {
        name: "Youtube",
        url: "https://www.youtube.com/channel/UCmcEhILeheJi6s_nEqrIF_Q",
        icon: fa_.FaYoutube
    }
];
const links = [
    {
        title: "Services",
        links: [
            {
                name: "Testimonials",
                url: "/testimonials"
            },
            {
                name: "Student Projects",
                url: "/student-works"
            },
            {
                name: "Events",
                url: "/events"
            },
            {
                name: "Hire",
                url: "/hire"
            },
            {
                name: "Be a Partner",
                url: "/partners"
            }
        ]
    },
    {
        title: "Class Plans",
        links: [
            {
                name: "Basic Class",
                url: "/class-plans#basic-class"
            },
            {
                name: "Advanced Class",
                url: "/class-plans#advanced-class"
            },
            {
                name: "Premium Class",
                url: "/class-plans#premium-class"
            },
            {
                name: "International",
                url: "/international"
            },
            {
                name: "Community",
                url: "https://chat.whatsapp.com/E6mQm7lHo412WAOOMP0Bwt"
            }
        ]
    },
    {
        title: "Contact Us",
        links: [
            {
                name: "perxels@gmail.com",
                url: "mailto:perxels@gmail.com"
            },
            {
                name: "+2348135369680",
                url: "tel:+2348135369680"
            }
        ]
    }
];

;// CONCATENATED MODULE: ./constant/testimonialContent.tsx
const testimonialSliderContent = [
    {
        id: 1,
        name: "Erica",
        title: "UIUX Designer, Nigeria",
        imgUrl: "/assets/images/testimonial/video/erica-large.jpg",
        smallImgUrl: "/assets/images/testimonial/video/erica-small.png",
        content: "“I had an amazing experience at Perxels Design School.”",
        video: "https://res.cloudinary.com/perxels/video/upload/v1672935451/Erica_Amos_Perxels_Alumni_ko0hvm.mp4"
    },
    {
        id: 2,
        name: "Joe",
        title: "Product Designer, USA",
        imgUrl: "/assets/images/testimonial/video/joe-large.jpg",
        smallImgUrl: "/assets/images/testimonial/video/joe-small.png",
        content: "“I had an amazing experience at Perxels Design School.”",
        video: "https://res.cloudinary.com/perxels/video/upload/v1672935443/Joseph_Nwaeze_Perxels_Alumni_f9cpq9.mp4"
    },
    {
        id: 3,
        name: "Mosope",
        title: "Product Designer, United Kingdom",
        imgUrl: "/assets/images/testimonial/video/mosope-large.jpg",
        smallImgUrl: "/assets/images/testimonial/video/mosope-small.png",
        content: "“I had an amazing experience at Perxels Design School.”",
        video: "https://res.cloudinary.com/perxels/video/upload/v1672935451/Mosope_Aderibigbe_Perxels_Alumni_slkfhr.mp4"
    },
    {
        id: 4,
        name: "Rebecca",
        title: "Product Designer, Nigeria",
        imgUrl: "/assets/images/testimonial/video/rebecca-large.jpg",
        smallImgUrl: "/assets/images/testimonial/video/rebecca-small.png",
        content: "“I had an amazing experience at Perxels Design School.”",
        video: "https://res.cloudinary.com/perxels/video/upload/v1672935462/Rebecca_Adeyoju_Perxels_Alumni_bkeimq.mp4"
    }
];
const testimonialContent = [
    {
        id: 1,
        imgUrl: "/assets/images/testimonial/new/test1.png",
        name: "Oyeyode Tunmise",
        title: "UIUX Designer",
        content: `Well leaving Perxels made me so emotional. it was such a pleasant and enlightening experience at Perxels, from the staffs to the scheme of work everything was nice and i would recommend them anytime to any aspiring UX/UI designer.`
    },
    {
        id: 2,
        imgUrl: "/assets/images/testimonial/new/test2.png",
        name: "Jacklyn Tilley Gyado",
        title: "UIUX Designer",
        content: `I started Perxels with zero knowledge about what I am transitioning into and not being sure about my decision. Now, based on what I've learnt I am taking things head on with UI Designing. I mean from not knowing what whitespace was to knowing my left and right in what I've been taught with all passion.`
    },
    {
        id: 3,
        imgUrl: "/assets/images/testimonial/new/test3.png",
        name: "Jasmine Eneanya",
        title: "Freelancer",
        content: `Really lovely and insightful experience. I learnt a lot during the program which would help me put all learnt skills to good use in the design field. Our Tutor really takes her time to explain each subject in detail over and over again till everyone understands.`
    },
    {
        id: 4,
        imgUrl: "/assets/images/testimonial/new/test4.png",
        name: "Waribugo Godspower",
        title: "UIUX Freelancer",
        content: `My time at Perxels was enlightening, fun and interesting. Learning from Fiwa was really good and it's the best online class I have had. Plus I met really interesting people who are fun to talk to and I have learned from them too.`
    },
    {
        id: 5,
        imgUrl: "/assets/images/testimonial/new/test5.png",
        name: "Jude Uche",
        title: "UIUX Designer",
        content: `It was an eye opener into the UI design world. The development and my attention to details when it comes to design has immensely been impacted positively by Perxels’s Design School. I would recommend Perxels to anyone who wants to learn UI/Ux Design, it's an amazing school.`
    },
    {
        id: 6,
        imgUrl: "/assets/images/testimonial/new/test6.png",
        name: "Morayo Idowu",
        title: "UIUX Designer",
        content: `My experience was good.. I remember when I began, I really had some issues with using fonts and creating good experiences.. But with time, I was able to learn how important fonts are in a design and how good an experience should be on a product.`
    },
    {
        id: 7,
        imgUrl: "/assets/images/testimonial/new/test7.png",
        name: "Rebecca Attoh",
        title: "UIUX Designer",
        content: `Joining Perxels was that birthday gift I gave myself this year. I don’t regret taking that bold step. My Growth was so glaring that everyone could see it. I’m grateful for my journey at Perxels and I am grateful for my Teacher ❤️`
    },
    {
        id: 8,
        imgUrl: "/assets/images/testimonial/new/test8.png",
        name: "Collins Efre",
        title: "UIUX Designer",
        content: `My experience at Perxels was really educational, as I developed extensive skills on UI/UX design and was programmed for real life experiences. It's the perfect start for a tech newbie in design.`
    },
    {
        id: 9,
        imgUrl: "/assets/images/testimonial/new/test9.png",
        name: "Muyiwa Adebayo",
        title: "UIUX Designer, Monkey Music",
        content: `Perxels helped me build a strong confidence in design skills, I learnt the most efficient and effective design process, soft skills and an eye for good designs.`
    }
];

;// CONCATENATED MODULE: ./constant/classGroupContent.tsx
const ClassGroupContent = [
    {
        title: "Basic Class",
        content: `
            This class is for beginners just starting out in design 
            to learn the fundamentals of UIUX design.
        `,
        link: "/class-plans#basic-class",
        image: "/assets/images/class-group/basic.jpg"
    },
    {
        title: "Advanced Class",
        content: `
            This class is for intermediate designers looking to expand 
            their UIUX design knowledge & skills.
        `,
        link: "/class-plans#advanced-class",
        image: "/assets/images/class-group/advance.jpg"
    },
    {
        title: "Premium Class",
        content: `
            This class is for anyone who want to learn everything in 
            UIUX design from basic to professional level.
        `,
        link: "/class-plans#premium-class",
        image: "/assets/images/class-group/premium.jpg"
    },
    {
        title: "International",
        content: `
        This class is for individuals who desire special design training to get International Design roles.
        `,
        link: "/international",
        image: "/assets/images/class-group/international.jpg"
    }
];
const classGroupDetails = [
    {
        title: "Basic Class",
        id: "basic-class",
        classDur: "7 Weeks.",
        classTime: "2-3 times a week.",
        classType: "Live Virtual Training.",
        installments: [
            "70% On Admission,",
            "30% after one month."
        ],
        tuition: "₦40,000",
        courseOutline: [
            "For beginners to learn the fundamentals of design; focus is majorly on UI (User Interface) design.",
            "What is UI design - difference between UI and UX design.",
            "Practical principle of UI design: typography, colours, layout, hierarchy, whitespace, icons, balance and alignment.",
            "Wireframes: creating standard low fidelity and high fidelity wireframes.",
            "Concept of drawing, sketching and mockups.",
            "Interpreting customer briefs and converting it to great designs.",
            "Learn how to design landing pages, mobile apps and dashboard screens.",
            "Work on real-life case studies and create a design portfolio.",
            "Mock interviews: showcasing your skills.",
            "Certificate of Completion."
        ]
    },
    {
        title: "Advanced Class",
        id: "advanced-class",
        classDur: "9 Weeks.",
        classTime: "2-3 times a week.",
        classType: "Live Virtual Training.",
        installments: [
            "70% On Admission,",
            "30% after one month."
        ],
        tuition: "₦70,000",
        courseOutline: [
            "For intermediate designers who have experience designing interface design looking to expand their design skills; this class is focused on UX (User Experience) design.",
            "What is UX design: why is it important to users and business. Learn different approaches to design thinking and how you can implement it.",
            "User research methods: qualitative & quantitative research, interpreting user feedbacks to designs.",
            "Creating maps: empathy map, customer journey map, experience map, storyboard, service blueprinting: customer actions, backstage actions and frontstage actions etc.",
            "Design systems: Style guide, pattern library, creating and maintaining design systems.",
            "Design full websites screens, mobile application screens (of about 40 Screens).",
            "Advanced testing and prototyping.",
            "Create an advanced design portfolio.",
            "Mock Interviews: showcasing your skills.",
            "Certificate of Completion."
        ]
    },
    {
        title: "Premium Class",
        id: "premium-class",
        classDur: "3 Months.",
        classTime: "2-3 times a week.",
        classType: "ONLINE TRAINING OR PHYSICAL Training.",
        installments: [
            "70% On Admission,",
            "30% after one month."
        ],
        tuition: "₦200,000",
        courseOutline: [
            "For anyone who wants to learn everything in UIUX design from beginner to professional level.",
            "It includes everything in the Basic and Advanced class curriculum.",
            "Learn how to use PRO design tools like Miro, Notion, Adobe illustrator, Figjam etc",
            "Exposure to design tips and tricks - shortcuts and resources.",
            "Work on complex case studies and projects that will build your problem solving skills.",
            "Direct mentorship with a Senior Product Designer.",
            "Learn how to collaborate with developers and product managers.",
            "Certificate of Completion.",
            "Job search support and guidance + job recommendation and placement when available**",
            "6 weeks internship placement after completing the training."
        ]
    }
];
const StudentWorks = [
    {
        imgUrl: "./assets/images/sudent-work/mosope.png",
        link: "/student-works/mosope"
    },
    {
        imgUrl: "./assets/images/sudent-work/daniju.png",
        link: "/student-works/daniju"
    },
    {
        imgUrl: "./assets/images/sudent-work/rebecca.png",
        link: "/student-works/rebecca"
    },
    {
        imgUrl: "./assets/images/sudent-work/favour.png",
        link: "/student-works/favour"
    }
];

;// CONCATENATED MODULE: ./constant/bannerContent.tsx
const bannerContent = {
    mainTitle: "DASHBOARD DESIGN:",
    subTitle: "THINGS YOU NEED TO KNOW ABOUT",
    time: "7:00 PM",
    date: "10TH SEPTEMBER, 2022.",
    location: "GOOGLE MEET.",
    bannerImage: "/assets/images/banner/bannerImage.png",
    description: "Dashboard design is a frequent request these days as businesses dream about a simple view that presents all information, shows trends and risky areas, and updates users on what happened — a view that will guide them into a bright financial future. Join us as Sebiomo gives us insights into dashboards design.",
    speakerName: "Sebiomo Anuoluwapo",
    speakerRole: "Design Lead, Voyance."
};

;// CONCATENATED MODULE: ./constant/workDetails.tsx
const workDetails = [
    {
        content1: [
            {
                id: "1",
                title: "Overview",
                description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. At adipiscing proin facilisis nulla ut suspendisse sit tempor. Turpis nibh sit elementum eros interdum purus. Pretium a mattis pellentesque et leo risus varius nunc."
            },
            {
                id: "1",
                title: "Overview",
                description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. At adipiscing proin facilisis nulla ut suspendisse sit tempor. Turpis nibh sit elementum eros interdum purus. Pretium a mattis pellentesque et leo risus varius nunc."
            }
        ],
        content2: [
            {
                id: "1",
                title: "Overview",
                description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. At adipiscing proin facilisis nulla ut suspendisse sit tempor. Turpis nibh sit elementum eros interdum purus. Pretium a mattis pellentesque et leo risus varius nunc."
            },
            {
                id: "1",
                title: "Overview",
                description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. At adipiscing proin facilisis nulla ut suspendisse sit tempor. Turpis nibh sit elementum eros interdum purus. Pretium a mattis pellentesque et leo risus varius nunc."
            }
        ]
    }
];

;// CONCATENATED MODULE: ./constant/hireCardContent.tsx
const hireCardContent = [
    {
        title: "UIUX Designers",
        description: "We have trained some of the best UIUX designers on the African continent, you can hire our trained designers with confidence.",
        icon: "/assets/images/hire/pencil.svg",
        bg: "brand.purple.500"
    },
    {
        title: "Software Developers",
        description: "In partnership with Schfordevs, a software development training school which is in our ecosystem, you can get vetted developers from here.",
        icon: "/assets/images/hire/cable.svg",
        bg: "brand.yellow.500",
        w: [
            "300px",
            "300px",
            "300px",
            "350.37px"
        ],
        r: "-1rem"
    },
    {
        title: "Product Managers.",
        description: "Getting skilled product managers can’t be more easy with Enoverlab, a training institute also in our ecosystem.",
        icon: "/assets/images/hire/traffic.svg",
        bg: "brand.pink.700",
        w: [
            "100px",
            "100px",
            "100px",
            "123.12px"
        ],
        r: "2rem"
    }
];

;// CONCATENATED MODULE: ./constant/sponsporshipContent.tsx
const instructions = [
    {
        id: 1,
        title: "Virtual Learning",
        description: "Perxels is an online training school and all class are fully virtual.",
        image: "./assets/images/sponsorship/virtual-learn.svg"
    },
    {
        id: 2,
        title: "Laptop and Internet",
        description: "A laptop and good internet is required to have a smooth learning experience.",
        image: "./assets/images/sponsorship/laptop-internet.svg"
    },
    {
        id: 3,
        title: "Installmental Payment",
        description: "You can split your payment into two and pay at different installments.",
        image: "./assets/images/sponsorship/virtual-learn.svg"
    },
    {
        id: 4,
        title: "Class Types",
        description: "You can apply for any of Perxels class plans; Basic class, Advanced class & Premium class.",
        image: "./assets/images/sponsorship/laptop-internet.svg"
    },
    {
        id: 5,
        title: "Online Curriculum",
        description: "100 undergraduates will receive 50% scholarship. Applicants are responsible for the other 50%.",
        image: "./assets/images/sponsorship/online-curriculum.svg"
    },
    {
        id: 6,
        title: "Social Interaction",
        description: "Students at Perxels collaborate on projects together.",
        image: "./assets/images/sponsorship/social-interaction.svg"
    }
];

;// CONCATENATED MODULE: ./constant/marketPlaceContent.tsx
const marketPlaceContent = [
    {
        id: 1,
        title: "Perxels pure cutton T-Shirt - Colour Purple",
        price: "₦3,000",
        imgUrl: "/assets/images/market-place/female-tshirt.jpg",
        link: "#"
    },
    {
        id: 2,
        title: "Perxels pure cutton Hoodie - Colour Purple",
        price: "₦6,000",
        imgUrl: "/assets/images/market-place/hoodie-purple.jpg",
        link: "#"
    },
    {
        id: 3,
        title: "Perxels pure cutton Hoodie - Colour Black",
        price: "₦10,000",
        imgUrl: "/assets/images/market-place/hoodie-black.jpg",
        link: "#"
    },
    {
        id: 4,
        title: "Perxels pure cutton Tote Bag - Colour Purple",
        price: "₦3,000",
        imgUrl: "/assets/images/market-place/cutton-tote.jpg",
        link: "#"
    },
    {
        id: 5,
        title: "Perxels pure cutton Hoodie - Colour Black",
        price: "₦10,000",
        imgUrl: "/assets/images/market-place/hoodie-black.jpg",
        link: "#"
    },
    {
        id: 6,
        title: "Perxels pure cutton Hoodie - Colour Purple",
        price: "₦6,000",
        imgUrl: "/assets/images/market-place/hoodie-purple.jpg",
        link: "#"
    },
    {
        id: 7,
        title: "Perxels pure cutton T-Shirt - Colour Purple",
        price: "₦3,000",
        imgUrl: "/assets/images/market-place/female-tshirt.jpg",
        link: "#"
    },
    {
        id: 8,
        title: "Perxels pure cutton Hoodie - Colour Purple",
        price: "₦6,000",
        imgUrl: "/assets/images/market-place/hoodie-purple.jpg",
        link: "#"
    },
    {
        id: 9,
        title: "Perxels pure cutton Hoodie - Colour Black",
        price: "₦10,000",
        imgUrl: "/assets/images/market-place/hoodie-black.jpg",
        link: "#"
    },
    {
        id: 10,
        title: "Perxels pure cutton Tote Bag - Colour Purple",
        price: "₦3,000",
        imgUrl: "/assets/images/market-place/cutton-tote.jpg",
        link: "#"
    },
    {
        id: 11,
        title: "Perxels pure cutton Hoodie - Colour Black",
        price: "₦10,000",
        imgUrl: "/assets/images/market-place/hoodie-black.jpg",
        link: "#"
    },
    {
        id: 12,
        title: "Perxels pure cutton Hoodie - Colour Purple",
        price: "₦6,000",
        imgUrl: "/assets/images/market-place/hoodie-purple.jpg",
        link: "#"
    }
];

;// CONCATENATED MODULE: ./constant/testimonialContentSecond.tsx
const testimonialContentSecond = [
    {
        id: 1,
        imgUrl: "/assets/images/testimonial/new/test1.png",
        name: "Oyeyode Muyiwa",
        title: "UIUX Designer",
        content: `Well, leaving Perxels made me so emotional. It was such a pleasant and enlightening experience. From the staff to the scheme of work, everything was nice and I would recommend them anytime to any aspiring UIUX designer.`
    },
    {
        id: 2,
        imgUrl: "/assets/images/testimonial/new/test2.png",
        name: "Jacklyn Tilley Gyado",
        title: "UIUX Designer",
        content: `I started Perxels with zero knowledge about what I am transitioning into and not being sure about my decision. Now, based on what I've learnt I am taking things head on with UI Designing. I mean from not knowing what whitespace was to knowing my left and right in what I've been taught with all passion.`
    },
    {
        id: 3,
        imgUrl: "/assets/images/testimonial/new/test3.png",
        name: "Jasmine Eneanya",
        title: "Freelancer",
        content: `Really lovely and insightful experience. I learnt a lot during the program which would help me put all learnt skills to good use in the design field. Our Tutor really takes her time to explain each subject in detail over and over again till everyone understands.`
    },
    {
        id: 4,
        imgUrl: "/assets/images/testimonial/new/test4.png",
        name: "Waribugo Godspower",
        title: "UIUX Freelancer",
        content: `My time at Perxels was enlightening, fun and interesting. Learning from Fiwa was really good and it's the best online class I have had. Plus I met really interesting people who are fun to talk to and I have learned from them too.`
    },
    {
        id: 5,
        imgUrl: "/assets/images/testimonial/new/test5.png",
        name: "Jude Uche",
        title: "UIUX Designer",
        content: `It was an eye opener into the UI design world. The development and my attention to details when it comes to design has immensely been impacted positively by Perxels’s Design School. I would recommend Perxels to anyone who wants to learn UI/Ux Design, it's an amazing school.`
    },
    {
        id: 6,
        imgUrl: "/assets/images/testimonial/new/test6.png",
        name: "Morayo Idowu",
        title: "UIUX Designer",
        content: `My experience was good.. I remember when I began, I really had some issues with using fonts and creating good experiences.. But with time, I was able to learn how important fonts are in a design and how good an experience should be on a product.`
    },
    {
        id: 7,
        imgUrl: "/assets/images/testimonial/new/test7.png",
        name: "Rebecca Attoh",
        title: "UIUX Designer",
        content: `Joining Perxels was that birthday gift I gave myself this year. I don’t regret taking that bold step. My Growth was so glaring that everyone could see it. I’m grateful for my journey at Perxels and I am grateful for my Teacher ❤️`
    },
    {
        id: 8,
        imgUrl: "/assets/images/testimonial/new/test8.png",
        name: "Collins Efre",
        title: "UIUX Designer",
        content: `My experience at Perxels was really educational, as I developed extensive skills on UI/UX design and was programmed for real life experiences. It's the perfect start for a tech newbie in design.`
    },
    {
        id: 9,
        imgUrl: "/assets/images/testimonial/new/test9.png",
        name: "Muyiwa Adebayo",
        title: "UIUX Designer, Monkey Music",
        content: `Perxels helped me build a strong confidence in design skills, I learnt the most efficient and effective design process, soft skills and an eye for good designs.`
    },
    {
        id: 10,
        imgUrl: "/assets/images/testimonial/new/test10.png",
        name: "Tolu Oluyole",
        title: "Freelance UI UX Designer",
        content: `My experience at Perxels was satisfactory. The weekly tasks and projects help me to improve my design skills, I also learned how to manage my time effectively and i'm able to scale up my design to industry standard. Enrolling for Perxels design school is the best career decision i have made.`
    },
    {
        id: 11,
        imgUrl: "/assets/images/testimonial/new/test11.png",
        name: "Olalekan Opadeji",
        title: "Freelance UIUX Designer",
        content: `Perxels has been a great place of learning for me as I look forward to learning more from their advance class and also grabbing every opportunity that comes thereafter.`
    },
    {
        id: 12,
        imgUrl: "/assets/images/testimonial/new/test12.png",
        name: "kehinde Adeyeye-Olufemi",
        title: "UIUX Designer",
        content: `My experience at Perxel  was surely a learning experience. The confidence and motivation it gave me, I couldn't get anywhere else. Most importantly, it is the place where I recognized my uniqueness and individuality.`
    },
    {
        id: 13,
        imgUrl: "/assets/images/testimonial/new/test13.png",
        name: "John Paul",
        title: "UIUX Designer",
        content: `UI/UX has been one aspect I have always wanted to learn, knowing about Perxels was one of the best gifts 2022 gave me, from the assignments to the constructive criticisms, to the holding of hands-on how to get useful resources. I am happy to say THAT I GOT REAL VALUE FOR MY MONEY!.`
    },
    {
        id: 14,
        imgUrl: "/assets/images/testimonial/new/test14.png",
        name: "Ikhuoria Victoria Itohan",
        title: "UIUX Designer",
        content: `My experience at Perxels was amazing. I learnt a lot of things and I am glad I took the decision to join the school. I am looking forward to the next level.`
    },
    {
        id: 15,
        imgUrl: "/assets/images/testimonial/new/test15.png",
        name: "Adeyoju Rebecca",
        title: "UIUX Designer",
        content: `Perxels was an amazing experience for me. I received more value than I paid for, and one interesting fact was the opportunity to have access to a design community that you can learn from indefinitely.`
    }
];

;// CONCATENATED MODULE: ./constant/index.ts











/***/ })

};
;