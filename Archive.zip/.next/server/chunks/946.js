"use strict";
exports.id = 946;
exports.ids = [946];
exports.modules = {

/***/ 1946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "_": () => (/* reexport */ Portfolio)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./components/index.ts + 9 modules
var components = __webpack_require__(6520);
;// CONCATENATED MODULE: ./constant/portfolioContent.tsx
const portfolioContent = [
    {
        id: 1,
        name: "Oladayo Oyindamola",
        image: "./assets/images/portfolio/testimony1.jpg",
        title: "FBIS technologies"
    },
    {
        id: 2,
        name: "Idris Ayoola",
        image: "./assets/images/portfolio/testimony2.jpg",
        title: "Product Designer, Vitract."
    },
    {
        id: 3,
        name: "Victoria Alli-Johnson",
        image: "./assets/images/portfolio/testimony3.jpg",
        title: "Product Designer, OneID Global Tech. Inc."
    },
    {
        id: 4,
        name: "Pelumi Oyelakin Bamgboye",
        image: "./assets/images/portfolio/testimony4.jpg",
        title: "BingHR"
    },
    {
        id: 5,
        name: "Makinde Bayowa",
        image: "./assets/images/portfolio/testimony5.jpg",
        title: "Product Designer, switcha.africa"
    },
    {
        id: 6,
        name: "Oluwabukola Jegede",
        image: "./assets/images/portfolio/testimony6.jpg",
        title: "CEO, The Giant Creative Brand"
    },
    {
        id: 7,
        name: "Blessed Chiamaka Onuoha",
        image: "./assets/images/portfolio/testimony7.jpg",
        title: "Product Designer, Interswitch"
    },
    {
        id: 8,
        name: "Nicholas Olaleye",
        image: "./assets/images/portfolio/testimony8.jpg",
        title: "Brand Designer, NowNow"
    },
    {
        id: 9,
        name: "Oladayo Oyindamola",
        image: "./assets/images/portfolio/testimony9.jpg",
        title: "FBIS technologies"
    },
    {
        id: 10,
        name: "Clavers Chabi",
        image: "./assets/images/portfolio/testimony10.jpg",
        title: "UI/UX All Web Service"
    },
    {
        id: 11,
        name: "Uthman Abolaji Osuolale",
        image: "./assets/images/portfolio/testimony11.jpg",
        title: "Product Designer, Calm Global Infotech"
    },
    {
        id: 12,
        name: "Duru Donald",
        image: "./assets/images/portfolio/testimony12.jpg",
        title: "Product Designer (Contract), Parivest"
    }
];

// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
;// CONCATENATED MODULE: ./features/portfolio/PortfolioCard.tsx



const PortfolioCard = ({ title , name , image  })=>{
    const [isHover, setIsHover] = external_react_default().useState(false);
    const [isLargerThan800] = (0,react_.useMediaQuery)("(max-width: 800px)", {
        ssr: true,
        fallback: false
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
        alignItems: "flex-end",
        onMouseEnter: ()=>setIsHover(true),
        onMouseLeave: ()=>setIsHover(false),
        w: "full",
        h: [
            "285.61px",
            "285.61px",
            "394px"
        ],
        bg: `url(${image}) center/cover no-repeat`,
        filter: [
            `grayscale('0')`,
            `grayscale('0')`,
            `grayscale('0')`,
            `grayscale(${isHover ? "0" : "100%"})`
        ],
        children: isHover || isLargerThan800 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
            w: "full",
            h: [
                "100px",
                "79px",
                "109px"
            ],
            px: [
                "0.875rem",
                "0.875rem",
                "1.25rem"
            ],
            py: "1.875rem",
            pos: "relative",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                    h: "full",
                    w: "full",
                    pos: "absolute",
                    top: "0",
                    left: "0",
                    zIndex: [
                        "0",
                        "0",
                        "0",
                        "-1"
                    ],
                    bg: "linear-gradient(180deg, #000000 0%, rgba(0, 0, 0, 0) 100%); transform: matrix(1, 0, 0, -1, 0, 0)"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                    pos: "relative",
                    zIndex: "1",
                    fontSize: [
                        "md",
                        "md",
                        "md",
                        "2xl"
                    ],
                    color: "brand.white",
                    children: name
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                    pos: "relative",
                    zIndex: "1",
                    fontSize: [
                        "0.55rem",
                        "0.55rem",
                        "0.6rem",
                        "sm"
                    ],
                    color: "brand.white",
                    children: title
                })
            ]
        }) : null
    });
};

;// CONCATENATED MODULE: ./features/portfolio/Portfolio.tsx







const Portfolio = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layouts/* MainContainer */.t, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                subTitle: "Our Portfolio",
                title: "Meet some of our Alumni",
                paragraph: "We are proud to see our students getting design jobs, impacting product teams with their skills and being paid well for their value.",
                maxW: [
                    "240px",
                    "full"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.SimpleGrid, {
                mb: [
                    "3.75rem",
                    "3.75rem",
                    "6.25rem"
                ],
                columns: [
                    2,
                    2,
                    2,
                    4
                ],
                spacing: [
                    "0.5rem",
                    "0.5rem",
                    "0"
                ],
                children: portfolioContent.map(({ id , title , name , image  })=>/*#__PURE__*/ jsx_runtime_.jsx(PortfolioCard, {
                        title: title,
                        name: name,
                        image: image,
                        id: id
                    }, id))
            })
        ]
    });
};

;// CONCATENATED MODULE: ./features/portfolio/index.ts



/***/ })

};
;