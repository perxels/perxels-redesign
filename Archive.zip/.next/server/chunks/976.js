"use strict";
exports.id = 976;
exports.ids = [976];
exports.modules = {

/***/ 2274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "y": () => (/* binding */ TestimonialSlider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./state/store.ts
var store = __webpack_require__(8857);
// EXTERNAL MODULE: ./state/features/TestimonialSlice.ts
var TestimonialSlice = __webpack_require__(9572);
;// CONCATENATED MODULE: ./features/testimonial/TestimonialSliderCard.tsx





const TestimonialSliderCard = ({ id , imgUrl , title , name , active , smallImgUrl , video , index  })=>{
    const dispatch = (0,store/* useAppDispatch */.TL)();
    const { selectedTestimonial , testimonials  } = (0,store/* useAppSelector */.CG)((state)=>state.testimonial);
    function handleSliderCardClick() {
        const prevSelectedTestimonial = selectedTestimonial;
        let fullTestimoials = [
            ...testimonials
        ];
        dispatch((0,TestimonialSlice/* setSelectedTestimonial */.Le)({
            id,
            name,
            title,
            imgUrl,
            smallImgUrl,
            video
        }));
        fullTestimoials[0] = {
            id,
            name,
            title,
            imgUrl,
            smallImgUrl,
            video
        };
        fullTestimoials[index] = prevSelectedTestimonial;
        dispatch((0,TestimonialSlice/* setTestimonials */.bw)(fullTestimoials));
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        pos: "relative",
        w: active ? "290px" : "235px",
        h: active ? "171px" : "138px",
        bg: "brand.pink.500",
        rounded: "8px",
        cursor: "pointer",
        onClick: handleSliderCardClick,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                w: "full",
                h: "full",
                src: smallImgUrl || imgUrl,
                alt: title,
                rounded: "8px"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                pos: "absolute",
                top: "0",
                left: "0",
                w: "full",
                h: "full",
                bg: "rgba(0, 0, 0, 0.25)",
                py: "0.875rem",
                px: "1rem",
                flexDir: "column",
                justifyContent: "flex-end",
                rounded: "8px",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                        color: "brand.white",
                        fontSize: "1rem",
                        children: name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                        color: "brand.white",
                        fontSize: "0.75rem",
                        children: title
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./features/testimonial/TestimonialSlider.tsx





const TestimonialSlider = ()=>{
    const dispatch = (0,store/* useAppDispatch */.TL)();
    const { testimonials  } = (0,store/* useAppSelector */.CG)((state)=>state.testimonial);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
        mt: "1.875rem",
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.HStack, {
            justifyContent: "space-between",
            w: "full",
            maxW: "800px",
            h: [
                "auto",
                "auto",
                "171px"
            ],
            spacing: "1rem",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.HStack, {
                justifyContent: "space-between",
                spacing: "1.25rem",
                display: [
                    "none",
                    "none",
                    "none",
                    "flex"
                ],
                w: "100%",
                h: "full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(TestimonialSliderCard, {
                        title: testimonials[1]?.title,
                        name: testimonials[1]?.name,
                        imgUrl: testimonials[1]?.imgUrl,
                        id: testimonials[1]?.id,
                        smallImgUrl: testimonials[1]?.smallImgUrl,
                        video: testimonials[1]?.video,
                        index: 1
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(TestimonialSliderCard, {
                        title: testimonials[2]?.title,
                        name: testimonials[2]?.name,
                        imgUrl: testimonials[2]?.imgUrl,
                        id: testimonials[2]?.id,
                        active: true,
                        smallImgUrl: testimonials[2]?.smallImgUrl,
                        video: testimonials[2]?.video,
                        index: 2
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(TestimonialSliderCard, {
                        title: testimonials[3]?.title,
                        name: testimonials[3]?.name,
                        imgUrl: testimonials[3]?.imgUrl,
                        id: testimonials[3]?.id,
                        smallImgUrl: testimonials[3]?.smallImgUrl,
                        video: testimonials[3]?.video,
                        index: 3
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 3102:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__);




const pulsate = _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.keyframes`
  0% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
  100% {
    transform: scale(1);
  }
`;
const TestimonialTooltip = ()=>{
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const pulseAnimation = `${pulsate} 1s ease-in-out infinite`;
    const showTooltip = ()=>{
        setActive(true);
    };
    const hideTooltip = ()=>{
        setActive(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
        onMouseEnter: showTooltip,
        onMouseLeave: hideTooltip,
        display: [
            "flex",
            "flex",
            "flex"
        ],
        flexDirection: "column",
        alignItems: "center",
        children: [
            active && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.SlideFade, {
                in: active,
                offsetY: "20px",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    h: "7.421875rem",
                    w: "14.125rem",
                    borderRadius: "0.299375rem",
                    bg: "#FFFFFF",
                    px: "0.625rem",
                    py: "0.875rem",
                    position: "absolute",
                    top: "-8rem",
                    left: "-6rem",
                    transition: "all 0.3s ease-in-out",
                    boxShadow: "0px 1.62712px 46.3729px rgba(0, 0, 0, 0.13)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                            pb: "0.71875rem",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Center, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    fontSize: "1.125rem",
                                    color: "#121212",
                                    fontWeight: "700",
                                    children: "NIGERIA \uD83C\uDDF3\uD83C\uDDEC"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                            width: "100%",
                            height: "0.0625rem",
                            bg: "#E5E5E5",
                            mb: "0.5rem"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.HStack, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            boxSize: "2.4375rem",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Img, {
                                                src: "/assets/images/tooltip/tooltip1.png",
                                                alt: "testimonial image"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            boxSize: "2.4375rem",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Img, {
                                                src: "/assets/images/tooltip/tooltip2.png",
                                                alt: "testimonial image"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            boxSize: "2.4375rem",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Img, {
                                                src: "/assets/images/tooltip/tooltip3.png",
                                                alt: "testimonial image"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            boxSize: "2.4375rem",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Img, {
                                                src: "/assets/images/tooltip/tooltip4.png",
                                                alt: "testimonial image"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                fontSize: "0.634375em",
                                                color: "#969696",
                                                children: "+100"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    pt: "0.5rem",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                            fontSize: "0.625em",
                                            fontWeight: "700",
                                            color: "#121212",
                                            children: "Read their stories"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                            fontSize: "1rem",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_3__.AiOutlineArrowRight, {})
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                boxSize: [
                    "1rem",
                    "1.875rem",
                    "1.875rem"
                ],
                animation: pulseAnimation,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Img, {
                    src: "/assets/icons/locationPoint.svg",
                    alt: "testimonial image"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TestimonialTooltip);


/***/ }),

/***/ 5992:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ TestimonyVideo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _state_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8857);





const TestimonyVideo = ()=>{
    const videoRef = react__WEBPACK_IMPORTED_MODULE_2___default().useRef(null);
    const [isPlaying, setIsPlaying] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const { selectedTestimonial  } = (0,_state_store__WEBPACK_IMPORTED_MODULE_4__/* .useAppSelector */ .CG)((state)=>state.testimonial);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setIsPlaying(false);
    }, [
        selectedTestimonial
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
        w: "full",
        h: isPlaying ? "600px" : [
            "318px",
            "318px",
            "475px"
        ],
        bg: "brand.white",
        overflow: "hidden",
        rounded: "10px",
        pos: "relative",
        children: [
            !isPlaying ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Img, {
                        w: "full",
                        h: "full",
                        objectFit: "contain",
                        src: selectedTestimonial?.imgUrl,
                        alt: "Testimonial Video"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Center, {
                        w: "full",
                        h: "full",
                        bg: "brand.overlay.100",
                        pos: "absolute",
                        top: "0",
                        left: "0",
                        cursor: "pointer",
                        flexDir: "column",
                        onClick: ()=>{
                            setIsPlaying(true);
                            videoRef.current?.play();
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Center, {
                                w: [
                                    "3.5rem",
                                    "4.375rem",
                                    "6.25rem"
                                ],
                                h: [
                                    "3.5rem",
                                    "4.375rem",
                                    "6.25rem"
                                ],
                                bg: "brand.yellow.300",
                                rounded: "full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                                    as: react_icons_bs__WEBPACK_IMPORTED_MODULE_3__.BsFillPlayFill,
                                    fontSize: [
                                        "2rem",
                                        "3rem"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                px: [
                                    "0.5rem",
                                    "0"
                                ],
                                fontSize: [
                                    "md",
                                    "xl",
                                    "3xl"
                                ],
                                textAlign: "center",
                                color: "brand.white",
                                mt: "1rem",
                                children: selectedTestimonial?.content
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                fontSize: [
                                    "xl",
                                    "3xl",
                                    "4xl"
                                ],
                                textAlign: "center",
                                color: "brand.white",
                                mt: "1rem",
                                children: [
                                    "- ",
                                    selectedTestimonial?.name
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                fontSize: [
                                    "sm",
                                    "xl",
                                    "3xl"
                                ],
                                color: "brand.white",
                                mt: "1rem",
                                children: selectedTestimonial?.title
                            })
                        ]
                    })
                ]
            }) : null,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                controls: true,
                style: {
                    height: "100%",
                    width: "auto",
                    margin: "0 auto"
                },
                ref: videoRef,
                src: selectedTestimonial?.video,
                onPause: ()=>setIsPlaying(false),
                onEnded: ()=>setIsPlaying(false)
            })
        ]
    });
};


/***/ }),

/***/ 3976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "gc": () => (/* reexport */ Testimonial),
  "WB": () => (/* reexport */ TestimonialGrid)
});

// UNUSED EXPORTS: TestimonialCard

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./features/testimonial/TestimonialCard.tsx



const TestimonialCard = ({ id , name , title , content , imgUrl  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        w: "full",
        py: "1.125rem",
        px: "1.75rem",
        bg: "brand.gray.300",
        rounded: "11.4px",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                gap: "0.5rem",
                alignItems: "center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                        src: imgUrl,
                        alt: name,
                        width: "78px",
                        height: "78px"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                        spacing: "0.25rem",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                w: "full",
                                textAlign: "left",
                                fontSize: "lg",
                                fontWeight: "bold",
                                color: "brand.dark.200",
                                children: name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                w: "full",
                                textAlign: "left",
                                fontSize: "xs",
                                color: "brand.dark.200",
                                children: title
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                fontSize: "lg",
                color: "brand.dark.200",
                mt: "1rem",
                children: content
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/index.ts + 9 modules
var components = __webpack_require__(6520);
// EXTERNAL MODULE: ./constant/index.ts + 9 modules
var constant = __webpack_require__(230);
// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
// EXTERNAL MODULE: ./features/testimonyhero/MobileTestimonialSlider.tsx
var MobileTestimonialSlider = __webpack_require__(1670);
// EXTERNAL MODULE: external "react-icons/fi"
var fi_ = __webpack_require__(2750);
;// CONCATENATED MODULE: ./features/testimonial/TestimonialGrid.tsx





const TestimonialGrid = ({ testimonialContent , isTestimonial  })=>{
    const [isLargerThan800] = (0,react_.useMediaQuery)("(max-width: 720px)", {
        ssr: true,
        fallback: false
    });
    const testimonialRef = (0,external_react_.useRef)(null);
    const slicedIndes = (0,external_react_.useRef)([
        0,
        3
    ]);
    const [lastTestimonialIndex, setLastTestimonialIndex] = external_react_default().useState(0);
    const [isUpdated, setIsUpdated] = external_react_default().useState(false);
    const trimmedContent = (0,external_react_.useMemo)(()=>{
        if (isLargerThan800 && !isTestimonial) {
            slicedIndes.current = lastTestimonialIndex !== 0 ? [
                lastTestimonialIndex,
                lastTestimonialIndex + 3
            ] : lastTestimonialIndex === testimonialContent.length ? [
                lastTestimonialIndex,
                testimonialContent.length
            ] : [
                0,
                3
            ];
        }
        if (isLargerThan800 && isTestimonial) {
            slicedIndes.current = lastTestimonialIndex !== 0 ? [
                lastTestimonialIndex,
                lastTestimonialIndex + 8
            ] : lastTestimonialIndex === testimonialContent.length ? [
                lastTestimonialIndex,
                testimonialContent.length
            ] : [
                0,
                8
            ];
        }
        if (!isLargerThan800) {
            slicedIndes.current = [
                0,
                testimonialContent.length
            ];
        }
        return testimonialContent?.slice(slicedIndes.current[0], slicedIndes.current[1]);
    }, [
        isLargerThan800,
        testimonialContent,
        isTestimonial,
        lastTestimonialIndex
    ]);
    const scrollDown = ()=>{
        window.scrollTo({
            top: testimonialRef?.current?.offsetTop,
            behavior: "smooth"
        });
    };
    (0,external_react_.useEffect)(()=>{
        if (isUpdated) {
            scrollDown();
        } else {
            setIsUpdated(true);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        lastTestimonialIndex
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.SimpleGrid, {
                columns: [
                    1,
                    2,
                    2,
                    3
                ],
                spacing: "1.375rem",
                py: "3.75rem",
                pb: [
                    "1.5rem",
                    "3.75rem"
                ],
                ref: testimonialRef,
                children: trimmedContent?.map(({ name , title , content , imgUrl , id  })=>/*#__PURE__*/ jsx_runtime_.jsx(TestimonialCard, {
                        id: id,
                        name: name,
                        title: title,
                        content: content,
                        imgUrl: imgUrl
                    }, id))
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                display: [
                    "flex",
                    "none"
                ],
                mb: "6rem",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                        w: "3.125rem",
                        h: "full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "3.125rem",
                            h: "3.125rem",
                            borderWidth: "1px",
                            borderColor: slicedIndes.current[0] === 0 ? "brand.gray.10" : "brand.purple.500",
                            rounded: "full",
                            cursor: "pointer",
                            transition: "all 0.2s ease-in-out",
                            as: "button",
                            disabled: slicedIndes.current[0] === 0,
                            onClick: ()=>{
                                setLastTestimonialIndex((prev)=>{
                                    if (isTestimonial) {
                                        return prev - 8 <= 0 ? 0 : prev - 8;
                                    }
                                    return prev - 3 <= 0 ? 0 : prev - 3;
                                });
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                as: fi_.FiArrowLeft,
                                fontSize: "1.5rem",
                                color: slicedIndes.current[0] === 0 ? "brand.gray.10" : "brand.purple.500"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                        w: "3.125rem",
                        h: "full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "3.125rem",
                            h: "3.125rem",
                            borderWidth: "1px",
                            borderColor: slicedIndes.current[1] >= testimonialContent.length ? "brand.gray.10" : "brand.purple.500",
                            rounded: "full",
                            cursor: "pointer",
                            transition: "all 0.2s ease-in-out",
                            as: "button",
                            disabled: slicedIndes.current[1] >= testimonialContent.length,
                            onClick: ()=>{
                                setLastTestimonialIndex((prev)=>{
                                    if (isTestimonial) {
                                        return prev + 8 >= testimonialContent.length ? testimonialContent.length - 1 : prev + 8;
                                    }
                                    return prev + 3 >= testimonialContent.length ? testimonialContent.length - 1 : prev + 3;
                                });
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                as: fi_.FiArrowRight,
                                fontSize: "1.5rem",
                                color: slicedIndes.current[1] >= testimonialContent.length ? "brand.gray.10" : "brand.purple.500"
                            })
                        })
                    })
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: ./features/testimonial/TestimonialSlider.tsx + 1 modules
var TestimonialSlider = __webpack_require__(2274);
// EXTERNAL MODULE: ./features/testimonial/TestimonyVideo.tsx
var TestimonyVideo = __webpack_require__(5992);
;// CONCATENATED MODULE: ./features/testimonial/Testimonial.tsx










const Testimonial = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layouts/* MainContainer */.t, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                subTitle: "Testimonials",
                title: "Hear what they say about us."
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                display: [
                    "none",
                    "none",
                    "none",
                    "block"
                ],
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(TestimonyVideo/* TestimonyVideo */.R, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(TestimonialSlider/* TestimonialSlider */.y, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                display: [
                    "block",
                    "block",
                    "block",
                    "none"
                ],
                children: /*#__PURE__*/ jsx_runtime_.jsx(MobileTestimonialSlider/* MobileTestimonialSlider */.L, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(TestimonialGrid, {
                testimonialContent: constant/* testimonialContent */.to
            })
        ]
    });
};

// EXTERNAL MODULE: ./features/testimonial/TestimonialTooltip.tsx
var TestimonialTooltip = __webpack_require__(3102);
;// CONCATENATED MODULE: ./features/testimonial/index.ts






/***/ }),

/***/ 1670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ MobileTestimonialSlider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _state_features_TestimonialSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9572);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(230);
/* harmony import */ var _state_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8857);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_8__);









const MobileTestimonialSlider = ()=>{
    const dispatch = (0,_state_store__WEBPACK_IMPORTED_MODULE_7__/* .useAppDispatch */ .TL)();
    const videoRef = react__WEBPACK_IMPORTED_MODULE_2___default().useRef(null);
    const { selectedTestimonial  } = (0,_state_store__WEBPACK_IMPORTED_MODULE_7__/* .useAppSelector */ .CG)((state)=>state.testimonial);
    const [isVideoOpen, setIsVideoOpen] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(false);
    const settings = {
        dots: true,
        arrows: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        cssEase: "linear",
        responsive: [
            {
                breakpoint: 1460,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4,
                    initialSlide: 4
                }
            },
            {
                breakpoint: 900,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_4___default()), {
                ...settings,
                children: _constant__WEBPACK_IMPORTED_MODULE_6__/* .testimonialSliderContent.map */ .qV.map(({ id , name , title , imgUrl , smallImgUrl , video , content  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            w: "full",
                            h: [
                                "226px",
                                "226px",
                                "226px"
                            ],
                            overflow: "hidden",
                            rounded: "10px",
                            pos: "relative",
                            onClick: ()=>{
                                dispatch((0,_state_features_TestimonialSlice__WEBPACK_IMPORTED_MODULE_5__/* .setSelectedTestimonial */ .Le)({
                                    id,
                                    name,
                                    title,
                                    imgUrl,
                                    smallImgUrl,
                                    video
                                }));
                                setIsVideoOpen(true);
                                videoRef.current?.play();
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Img, {
                                    w: "full",
                                    h: "full",
                                    src: smallImgUrl,
                                    alt: "Testimonial Video",
                                    display: [
                                        "none",
                                        "none",
                                        "block",
                                        "block"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Img, {
                                    w: "full",
                                    h: "full",
                                    objectFit: "cover",
                                    src: smallImgUrl,
                                    alt: "Testimonial Video",
                                    display: [
                                        "block",
                                        "block",
                                        "none",
                                        "none"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Center, {
                                    w: "full",
                                    h: "full",
                                    bg: "brand.overlay.100",
                                    pos: "absolute",
                                    top: "0",
                                    left: "0",
                                    cursor: "pointer",
                                    flexDir: "column",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Center, {
                                            w: [
                                                "3.5rem",
                                                "4.375rem",
                                                "6.25rem"
                                            ],
                                            h: [
                                                "3.5rem",
                                                "4.375rem",
                                                "6.25rem"
                                            ],
                                            bg: "brand.yellow.300",
                                            rounded: "full",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                                                as: react_icons_bs__WEBPACK_IMPORTED_MODULE_3__.BsFillPlayFill,
                                                fontSize: [
                                                    "2rem",
                                                    "3rem"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                            px: [
                                                "0.5rem",
                                                "0"
                                            ],
                                            fontSize: [
                                                "md",
                                                "xl",
                                                "3xl"
                                            ],
                                            textAlign: "center",
                                            color: "brand.white",
                                            mt: "1rem",
                                            maxW: "220px",
                                            children: content
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Heading, {
                                            fontSize: [
                                                "xl",
                                                "3xl",
                                                "4xl"
                                            ],
                                            textAlign: "center",
                                            color: "brand.white",
                                            mt: "1rem",
                                            children: [
                                                "- ",
                                                name
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                            fontSize: [
                                                "sm",
                                                "xl",
                                                "3xl"
                                            ],
                                            color: "brand.white",
                                            mt: "1rem",
                                            children: title
                                        })
                                    ]
                                })
                            ]
                        }, id)
                    }, id))
            }),
            isVideoOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Center, {
                onClick: ()=>{
                    setIsVideoOpen(false);
                    videoRef.current?.pause();
                },
                px: "1rem",
                pos: "fixed",
                top: "0",
                left: "0",
                w: "100vw",
                h: "100vh",
                bg: "rgba(0, 0, 0, .4)",
                zIndex: "999",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        pos: "relative",
                        w: "full",
                        rounded: "8px",
                        overflow: "hidden",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                            autoPlay: true,
                            controls: true,
                            ref: videoRef,
                            src: selectedTestimonial.video
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
                        onClick: ()=>{
                            setIsVideoOpen(false);
                            videoRef.current?.pause();
                        },
                        pos: "absolute",
                        top: "13rem",
                        right: "1rem",
                        w: "2rem",
                        h: "2rem",
                        px: "1.5rem",
                        bg: "brand.purple.500",
                        rounded: "8px",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_1__.Icon, {
                            as: react_icons_io__WEBPACK_IMPORTED_MODULE_8__.IoIosClose,
                            fontSize: "2rem",
                            color: "brand.white"
                        })
                    })
                ]
            })
        ]
    });
};


/***/ })

};
;