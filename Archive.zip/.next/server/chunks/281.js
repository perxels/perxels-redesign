"use strict";
exports.id = 281;
exports.ids = [281];
exports.modules = {

/***/ 1892:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ speakerHeroData),
/* harmony export */   "o": () => (/* binding */ heroData)
/* harmony export */ });
const heroData = [
    {
        title: "In-depth training and mentorship.",
        content: "With experienced designers who will not only teach you practically, but would also mentor you through.",
        image: "/assets/icons/chart.svg",
        color: "brand.purple.100"
    },
    {
        title: "Internship placement.",
        content: "At the end of the training you would be placed into an internship program where you get to use your design skills in a product team.",
        image: "/assets/icons/dekstop.svg",
        color: "brand.yellow.100"
    },
    {
        title: "Supportive design community.",
        content: "A fun & interactive community of designers from all over the world who are committed to helping each other grow.",
        image: "/assets/icons/flame.svg",
        color: "brand.pink.100"
    }
];
const speakerHeroData = [
    {
        title: "Make Impact",
        content: "By sharing a bit of your knowledge and experience, you are impacting the lives of many upcoming designers and tech talents",
        image: "/assets/icons/chart.svg",
        color: "brand.purple.100"
    },
    {
        title: "Improve industry standard",
        content: "Your contribution will help to improve the design industry standard in Nigeria and beyond as young designers would learn what is right early",
        image: "/assets/icons/dekstop.svg",
        color: "brand.yellow.100"
    },
    {
        title: "Expand your personal brand",
        content: "Being a speaker helps you grow your personal brand beyond your primary network, and this can ultimately help you access opportunities both locally and internationally",
        image: "/assets/icons/flame.svg",
        color: "brand.pink.100"
    }
];


/***/ }),

/***/ 8281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "V": () => (/* reexport */ Hero),
  "n": () => (/* reexport */ HeroSubSection)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./constant/heroData.tsx
var heroData = __webpack_require__(1892);
// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
;// CONCATENATED MODULE: ./features/home/HeroCard.tsx



const HeroCard = ({ title , content , image , color  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        py: [
            "2rem",
            "3.25rem"
        ],
        px: [
            "2rem",
            "3.5rem"
        ],
        borderWidth: "1px",
        borderColor: color,
        rounded: "22px",
        className: "section-card",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                width: "6.384rem",
                height: "6.384rem",
                rounded: "full",
                bg: color,
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                    src: image,
                    width: 42,
                    height: 42,
                    alt: title
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                fontSize: "xl",
                mt: "1.875rem",
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                fontSize: "md",
                mt: "0.625rem",
                color: "brand.gray.400",
                children: content
            })
        ]
    });
};

// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(4287);
var external_gsap_default = /*#__PURE__*/__webpack_require__.n(external_gsap_);
// EXTERNAL MODULE: external "gsap/dist/ScrollTrigger"
var ScrollTrigger_ = __webpack_require__(4965);
var ScrollTrigger_default = /*#__PURE__*/__webpack_require__.n(ScrollTrigger_);
;// CONCATENATED MODULE: ./features/home/HeroSubSection.tsx








external_gsap_default().registerPlugin((ScrollTrigger_default()));
const HeroSubSection = ({ data =heroData/* heroData */.o  })=>{
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            external_gsap_default().from(".section-grid", {
                opacity: "0",
                y: 200,
                duration: 1,
                delay: 1,
                scrollTrigger: {
                    trigger: ".section-grid"
                }
            });
        });
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.SimpleGrid, {
            py: [
                "3.75rem",
                "3.75rem",
                "7.125rem"
            ],
            columns: [
                1,
                1,
                2,
                3
            ],
            spacing: [
                "2.5rem",
                "2.5rem",
                "2.5rem",
                "3.5rem"
            ],
            className: "section-grid",
            children: data.map(({ title , content , image , color  })=>/*#__PURE__*/ jsx_runtime_.jsx(HeroCard, {
                    color: color,
                    title: title,
                    content: content,
                    image: image
                }, image))
        })
    });
};

;// CONCATENATED MODULE: ./features/home/HeroAnimation.tsx


// import Image from 'next/image'

const HeroAnimation = ()=>{
    const [switcher, setSwitcher] = (0,external_react_.useState)(1);
    (0,external_react_.useEffect)(()=>{
        const interval = setInterval(()=>{
            setSwitcher((prev)=>prev === 1 ? 2 : prev === 2 ? 3 : 1);
        }, 3000);
        return ()=>clearInterval(interval);
    }, []);
    const mainImage = (0,external_react_.useMemo)(()=>{
        return switcher === 1 ? "/assets/images/hero/1-hero.png" : switcher === 2 ? "/assets/images/hero/2-hero.png" : "/assets/images/hero/3-hero.png";
    }, [
        switcher
    ]);
    const leftImage = (0,external_react_.useMemo)(()=>{
        return switcher === 1 ? "/assets/images/hero/2-hero.png" : switcher === 2 ? "/assets/images/hero/3-hero.png" : "/assets/images/hero/1-hero.png";
    }, [
        switcher
    ]);
    const rightImage = (0,external_react_.useMemo)(()=>{
        return switcher === 1 ? "/assets/images/hero/3-hero.png" : switcher === 2 ? "/assets/images/hero/1-hero.png" : "/assets/images/hero/2-hero.png";
    }, [
        switcher
    ]);
    const animationContent = (0,external_react_.useMemo)(()=>{
        if (switcher === 1) return {
            name: "Mosope Awolowo",
            desc: "Accountant turned UI/UX Designer",
            color: "#FF9CAE"
        };
        if (switcher === 2) return {
            name: "Anita Opara",
            desc: "Site Engineer turned UI/UX Designer",
            color: "#7971FF"
        };
        return {
            name: "Gbenro Abimbola",
            desc: "Lawyer turned UI/UX Designer",
            color: "#7971FF"
        };
    }, [
        switcher
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
        mt: "2.625rem",
        columns: [
            1,
            1,
            1,
            3
        ],
        gap: [
            "4rem",
            "4rem",
            "4rem",
            "2rem",
            "6rem"
        ],
        className: "hero-animation",
        opacity: 0,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                display: [
                    "none",
                    "none",
                    "none",
                    "block"
                ],
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                    width: "226px",
                    height: "auto",
                    alt: "hero",
                    src: leftImage
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                pos: "relative",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                        display: [
                            "none",
                            "none",
                            "none",
                            "block"
                        ],
                        pos: "absolute",
                        left: "-60%",
                        top: [
                            "60%",
                            "60%",
                            "60%",
                            "60%",
                            "40%"
                        ],
                        src: "/assets/icons/arrow_01.svg",
                        alt: "arrow left",
                        width: "11.65rem",
                        height: "11.65rem"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                        display: [
                            "none",
                            "none",
                            "none",
                            "block"
                        ],
                        pos: "absolute",
                        right: "-60%",
                        top: [
                            "60%",
                            "60%",
                            "60%",
                            "60%",
                            "40%"
                        ],
                        src: "/assets/icons/arrow_02.svg",
                        alt: "arrow left",
                        width: "11.65rem",
                        height: "11.65rem"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                        width: [
                            "295px",
                            "295px",
                            "295px",
                            "354px"
                        ],
                        height: [
                            "466px",
                            "466px",
                            "466px",
                            "559px"
                        ],
                        mx: "auto",
                        maxW: "auto",
                        alt: "hero",
                        src: mainImage
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                        as: "span",
                        bg: animationContent.color,
                        rounded: "20px",
                        px: "1rem",
                        py: [
                            "0.875rem",
                            "1.5rem"
                        ],
                        pos: "absolute",
                        bottom: [
                            "-2rem",
                            "-2rem",
                            "-2rem",
                            "-3rem"
                        ],
                        right: [
                            "0.5rem",
                            "0.5rem",
                            "6rem",
                            "-7rem"
                        ],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                fontSize: [
                                    "md",
                                    "lg",
                                    "lg",
                                    "xl"
                                ],
                                color: "brand.white",
                                children: animationContent?.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                fontSize: [
                                    "md",
                                    "lg",
                                    "xl"
                                ],
                                color: "brand.white",
                                children: animationContent?.desc
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                ml: "auto",
                display: [
                    "none",
                    "none",
                    "none",
                    "block"
                ],
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                    width: "226px",
                    height: "auto",
                    alt: "hero",
                    src: rightImage
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./features/home/Hero.tsx






// import Link from 'next/link'
const Hero = ()=>{
    const heroRef = (0,external_react_.useRef)(null);
    const headingRef = (0,external_react_.useRef)(null);
    const descRef = (0,external_react_.useRef)(null);
    const buttonWrapper = (0,external_react_.useRef)(null);
    const tl = (0,external_react_.useRef)(external_gsap_default().timeline({
        paused: true
    }));
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            tl.current.to(headingRef.current, {
                opacity: 1,
                duration: 1,
                delay: 1
            }).to(descRef.current, {
                opacity: 1,
                duration: 1
            }, "-=0.5").to(buttonWrapper.current, {
                opacity: 1,
                duration: 1
            }, "-=0.5").to(".hero-animation", {
                opacity: 1,
                y: 0,
                duration: 1
            }, "-=0.5").play();
        }, heroRef);
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: heroRef,
        w: "full",
        bg: `url(./assets/images/heroBg.png) center/cover no-repeat`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layouts/* MainContainer */.t, {
            bg: "none",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                    maxW: "556px",
                    fontSize: [
                        "2.3rem",
                        "3rem",
                        "4.375rem"
                    ],
                    fontWeight: "black",
                    textAlign: [
                        "left",
                        "left",
                        "left",
                        "center"
                    ],
                    m: [
                        "0",
                        "0",
                        "0",
                        "0 auto"
                    ],
                    pt: "3.375rem",
                    ref: headingRef,
                    lineHeight: 1.2,
                    opacity: 0,
                    children: "Learn, Live, Love UIUX Design"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                    textAlign: [
                        "left",
                        "left",
                        "left",
                        "center"
                    ],
                    mt: "0.5rem",
                    fontSize: "2xl",
                    ref: descRef,
                    opacity: 0,
                    children: "Equipping designers to solve problems with design."
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                    ref: buttonWrapper,
                    opacity: 0,
                    mt: "1.5rem",
                    display: [
                        "block",
                        "block",
                        "block",
                        "none"
                    ],
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                        href: "/class-plans",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            children: "Start Here"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(HeroAnimation, {})
            ]
        })
    });
};

;// CONCATENATED MODULE: ./features/home/index.ts




/***/ })

};
;