"use strict";
exports.id = 559;
exports.ids = [559];
exports.modules = {

/***/ 5731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "U1": () => (/* reexport */ EventCommunity),
  "$M": () => (/* reexport */ EventForm),
  "IU": () => (/* reexport */ EventHero),
  "X0": () => (/* reexport */ EventInput),
  "TU": () => (/* reexport */ EventPlayback),
  "vA": () => (/* reexport */ EventTwitter)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: ./constant/index.ts + 9 modules
var constant = __webpack_require__(230);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(4287);
var external_gsap_default = /*#__PURE__*/__webpack_require__.n(external_gsap_);
;// CONCATENATED MODULE: ./features/events/EventHero.tsx









const EventHero = ()=>{
    const mainRef = (0,external_react_.useRef)(null);
    const tl = (0,external_react_.useRef)(external_gsap_default().timeline({
        paused: true
    }));
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            tl.current.from(".ama-title", {
                opacity: 0,
                y: 100,
                duration: 0.5,
                delay: 0.5
            }).from(".ama-main-title", {
                opacity: 0,
                y: 100,
                duration: 1
            }).from(".ama-other-content", {
                opacity: 0,
                y: 100,
                duration: 1
            }).from(".speaker-section", {
                opacity: 0,
                y: 100,
                duration: 1
            }).from(".speaker-form", {
                opacity: 0,
                y: 100,
                duration: 1
            }).from(".about-speaker", {
                opacity: 0,
                y: 100,
                duration: 1
            }).play();
        }, mainRef);
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
        bg: `url(./assets/images/heroBg.png) center/cover no-repeat`,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
            py: "2rem",
            w: "full",
            ref: mainRef,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Grid, {
                w: "full",
                templateColumns: [
                    "1fr",
                    "1fr",
                    "1fr",
                    "1.5fr 1fr"
                ],
                gap: 12,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                backgroundColor: "transparent",
                                border: "1px solid #E3719C",
                                color: "#E3719C",
                                borderRadius: "5px",
                                _hover: {
                                    backgroundColor: "#E3719C",
                                    color: "#fff"
                                },
                                mb: {
                                    base: 4,
                                    md: 7
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    children: "AMA SESSION"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Heading, {
                                fontSize: {
                                    base: "6xl",
                                    md: "7xl",
                                    lg: "8xl"
                                },
                                color: "brand.dark.100",
                                lineHeight: "110%",
                                mb: {
                                    base: 4,
                                    md: 4
                                },
                                className: "ama-main-title",
                                children: [
                                    constant/* bannerContent.mainTitle */.Gj.mainTitle,
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    constant/* bannerContent.subTitle */.Gj.subTitle
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                                className: "ama-other-content",
                                columnGap: {
                                    base: "0.5rem",
                                    lg: "1.3rem"
                                },
                                mt: "1rem",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                        color: "brand.gray.400",
                                        display: "flex",
                                        alignItems: "center",
                                        columnGap: {
                                            base: "0.3rem",
                                            lg: "0.5625rem"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                fontSize: {
                                                    base: "1rem",
                                                    lg: "1.79875rem"
                                                },
                                                fontWeight: "bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiTimer2Line, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                fontSize: {
                                                    base: "0.7rem",
                                                    lg: "1.295rem"
                                                },
                                                fontWeight: "bold",
                                                children: constant/* bannerContent.time */.Gj.time
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                        color: "brand.gray.400",
                                        display: "flex",
                                        alignItems: "center",
                                        columnGap: {
                                            base: "0.3rem",
                                            lg: "0.5625rem"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                fontSize: {
                                                    base: "1rem",
                                                    lg: "1.79875rem"
                                                },
                                                fontWeight: "bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineCalendar, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                fontSize: {
                                                    base: "0.7rem",
                                                    lg: "1.295rem"
                                                },
                                                fontWeight: "bold",
                                                children: constant/* bannerContent.date */.Gj.date
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                        color: "brand.gray.400",
                                        display: "flex",
                                        alignItems: "center",
                                        columnGap: {
                                            base: "0.3rem",
                                            lg: "0.5625rem"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                                boxSize: {
                                                    base: "1rem",
                                                    lg: "1.79875rem"
                                                },
                                                fontWeight: "bold",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                                    src: "/assets/icons/gps.svg",
                                                    alt: "location"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                fontSize: {
                                                    base: "0.7rem",
                                                    lg: "1.295rem"
                                                },
                                                fontWeight: "bold",
                                                children: constant/* bannerContent.location */.Gj.location
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                className: "speaker-section",
                                mt: {
                                    base: 4,
                                    md: 16
                                },
                                mb: {
                                    base: 3.5,
                                    md: 10
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        fontSize: {
                                            base: "0.9rem",
                                            lg: "1.25rem"
                                        },
                                        fontWeight: "bold",
                                        color: "brand.gray.400",
                                        textTransform: "uppercase",
                                        mb: {
                                            base: 2,
                                            md: 4
                                        },
                                        children: "Speaker:"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                                        alignItems: "center",
                                        columnGap: "0.725625rem",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                                boxSize: {
                                                    base: "5.1875rem",
                                                    lg: "7.5rem"
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                                    borderRadius: "50%",
                                                    src: constant/* bannerContent.bannerImage */.Gj.bannerImage,
                                                    alt: "speakerImg"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                        fontSize: {
                                                            base: "1.10965rem",
                                                            lg: "1.596875rem"
                                                        },
                                                        fontWeight: "bold",
                                                        color: "brand.dark.100",
                                                        children: constant/* bannerContent.speakerName */.Gj.speakerName
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                        fontSize: {
                                                            base: "0.806875rem",
                                                            lg: "1.25rem"
                                                        },
                                                        color: "#5F6368",
                                                        children: constant/* bannerContent.speakerRole */.Gj.speakerRole
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                className: "about-speaker",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        fontSize: {
                                            base: "0.9rem",
                                            lg: "1.25rem"
                                        },
                                        fontWeight: "bold",
                                        color: "brand.gray.400",
                                        textTransform: "uppercase",
                                        mb: {
                                            base: 2,
                                            md: 4
                                        },
                                        children: "About Session:"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        fontSize: {
                                            base: "0.941875rem",
                                            lg: "1.306875rem"
                                        },
                                        color: "brand.dark.200",
                                        lineHeight: {
                                            base: "1.626875rem",
                                            lg: "2.2575rem"
                                        },
                                        children: constant/* bannerContent.description */.Gj.description
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(EventForm, {})
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/bi"
var bi_ = __webpack_require__(6652);
// EXTERNAL MODULE: ./components/index.ts + 9 modules
var components = __webpack_require__(6520);
// EXTERNAL MODULE: external "next-share"
var external_next_share_ = __webpack_require__(8797);
;// CONCATENATED MODULE: ./features/events/EventForm.tsx









const EventForm = ()=>{
    const { hasCopied , onCopy  } = (0,react_.useClipboard)("https://perxels.com/events/dashboard-designs");
    const formRef = (0,external_react_.useRef)(null);
    const [loading, setLoading] = (0,external_react_.useState)(false);
    const scriptUrl = "https://script.google.com/macros/s/AKfycbwT-2FTNzCeyQ1f9bZQgcRoTuepP0kHNVemyh5jmrP_H3z7p_EaDNNMAlcWrpdZJj4Cvw/exec";
    const { isOpen , onOpen , onClose  } = (0,react_.useDisclosure)();
    const handleSubmit = (e)=>{
        e.preventDefault();
        setLoading(true);
        const inputData = e.target;
        const formData = new FormData();
        formData.append("name", inputData.name.value);
        formData.append("email", inputData.email.value);
        formData.append("phone", inputData.phone.value);
        formData.append("howyouknew", inputData.howyouknew.value);
        formData.append("questions", inputData.questions.value);
        //current date and time
        formData.append("date", new Date().toLocaleString());
        // const data = Object.fromEntries(formData)
        // console.log(data)
        fetch(scriptUrl, {
            method: "POST",
            body: formData
        }).then((response)=>{
            if (response.status === 201 || 200) {
                setLoading(false);
                console.log("working");
                onOpen();
            } else {}
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* SuccessModal */.i_, {
                isOpen: isOpen,
                onClose: onClose,
                title: "Your registration has been received.",
                description: "You will receive an email with the meeting link shortly."
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                as: "form",
                spacing: {
                    base: "1.2rem",
                    md: "1.209375rem"
                },
                backgroundColor: "#F6F7FD",
                px: [
                    "1.5rem",
                    "1.5rem",
                    "1.5rem",
                    "2.5rem"
                ],
                py: [
                    "1.5rem",
                    "1.5rem",
                    "1.5rem",
                    "3.5rem"
                ],
                rounded: "10px",
                onSubmit: handleSubmit,
                className: "speaker-form",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(EventInput, {
                        id: "name",
                        type: "text",
                        placeholder: "Full Name*"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(EventInput, {
                        id: "email",
                        type: "email",
                        placeholder: "Email Address*"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(EventInput, {
                        id: "phone",
                        type: "tel",
                        placeholder: "Phone Number*"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.FormControl, {
                        id: "how",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Select, {
                            backgroundColor: "#FCFCFC",
                            border: "0.406872px solid #B4B4B4",
                            placeholder: "How did you get to know about Us?",
                            _placeholder: {
                                color: "#B4B4B4"
                            },
                            name: "howyouknew",
                            h: "3.5rem",
                            isRequired: true,
                            _focusVisible: {
                                outline: "none"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "Whatsapp",
                                    children: "Whatsapp"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "Instagram",
                                    children: "Instagram"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "Facebook",
                                    children: "Facebook"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "Twitter",
                                    children: "Twitter"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "Friend",
                                    children: "Friend"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: "Others",
                                    children: "Others"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.FormControl, {
                        id: "questions",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Textarea, {
                            backgroundColor: "#FCFCFC",
                            outline: "none",
                            border: "0.406872px solid #B4B4B4",
                            placeholder: "Questions for the Session",
                            name: "questions",
                            _focusVisible: {
                                outline: "none"
                            }
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                        width: "full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            h: "3.1875rem",
                            w: "full",
                            type: "submit",
                            fontSize: "lg",
                            children: "Register for this Session"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                        w: "full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                fontSize: "xl",
                                fontWeight: "bold",
                                color: "brand.gray.400",
                                textAlign: "center",
                                mb: "1.5rem",
                                children: "Spread the word"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                    w: "full",
                                    bgColor: "#FCFCFC",
                                    display: "flex",
                                    fontSize: "20px",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    p: "0.5rem",
                                    mb: "1.5rem",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Input, {
                                            w: "70%",
                                            border: "0 none",
                                            outline: "0 none",
                                            _focus: {
                                                outline: "0 none",
                                                border: "0 none",
                                                boxShadow: "none"
                                            },
                                            value: "https://perxels.com/events",
                                            color: "#000000",
                                            fontSize: "0.915625rem",
                                            type: "disabled"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(bi_.BiCopy, {
                                            onClick: onCopy,
                                            cursor: "pointer"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.HStack, {
                                spacing: {
                                    base: 4,
                                    lg: 4
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                        w: "full",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_next_share_.WhatsappShareButton, {
                                            url: "https://perxels.com/events",
                                            title: "DASHBOARD DESIGN: THINGS YOU NEED TO KNOW ABOUT",
                                            separator: ":: ",
                                            style: {
                                                width: "100%"
                                            },
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Button, {
                                                backgroundColor: "transparent",
                                                border: "1px solid #121212",
                                                color: "#121212",
                                                _hover: {
                                                    backgroundColor: "#121212",
                                                    color: "#fff"
                                                },
                                                w: "full",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiWhatsappFill, {}),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                        ml: {
                                                            base: "0.35rem",
                                                            lg: "0.75rem"
                                                        },
                                                        fontSize: {
                                                            base: "1rem",
                                                            lg: "1rem"
                                                        },
                                                        children: "Share"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                        w: "full",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_next_share_.TwitterShareButton, {
                                            url: "https://perxels.com/events",
                                            title: "DASHBOARD DESIGN: THINGS YOU NEED TO KNOW ABOUT",
                                            style: {
                                                width: "100%"
                                            },
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Button, {
                                                backgroundColor: "transparent",
                                                border: "1px solid #121212",
                                                color: "#121212",
                                                _hover: {
                                                    backgroundColor: "#121212",
                                                    color: "#fff"
                                                },
                                                w: "full",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {}),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                        ml: {
                                                            base: "0.35rem",
                                                            lg: "0.75rem"
                                                        },
                                                        fontSize: {
                                                            base: "1rem",
                                                            lg: "1rem"
                                                        },
                                                        children: "Tweet"
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./features/events/EventInput.tsx


const EventInput = ({ id , type , placeholder  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.FormControl, {
        id: id,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Input, {
            backgroundColor: "#FCFCFC",
            border: "0.406872px solid #B4B4B4",
            type: type,
            placeholder: placeholder,
            _focus: {
                border: "none"
            },
            name: id,
            h: "3.5rem",
            isRequired: true,
            _focusVisible: {
                outline: "none"
            }
        })
    });
};

// EXTERNAL MODULE: external "gsap/dist/ScrollTrigger"
var ScrollTrigger_ = __webpack_require__(4965);
var ScrollTrigger_default = /*#__PURE__*/__webpack_require__.n(ScrollTrigger_);
;// CONCATENATED MODULE: ./features/events/EventCommunity.tsx







external_gsap_default().registerPlugin((ScrollTrigger_default()));
const EventCommunity = ()=>{
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            external_gsap_default().from(".event-comm", {
                opacity: "0",
                y: 200,
                duration: 1,
                delay: 1,
                scrollTrigger: {
                    trigger: ".event-comm",
                    start: "-900 top",
                    end: "bottom bottom"
                }
            });
        });
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
            className: "event-comm",
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                bg: {
                    base: `linear-gradient(360deg, #000000 23.68%, rgba(0, 0, 0, 0) 106.41%),url(assets/images/events/communitymobile.png) center/cover no-repeat`,
                    lg: `linear-gradient(90deg, rgba(6, 6, 6, 0.88) 0%, rgba(6, 6, 6, 0) 133.43%),url(assets/images/events/eventscommunity.png) center/cover no-repeat`
                },
                w: "full",
                h: {
                    base: "auto",
                    lg: "29.5rem"
                },
                position: "relative",
                p: {
                    base: "10.3125rem 1.25rem 2.1875rem 1.25rem",
                    lg: "8.3125rem 5.3125rem"
                },
                rounded: "30px",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                            color: "brand.white",
                            fontSize: {
                                base: "1.705rem",
                                md: "3.125rem"
                            },
                            fontWeight: "bold",
                            children: "Join Our Free Community."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                            color: "brand.white",
                            fontSize: {
                                base: "1.125rem",
                                md: "1.125rem"
                            },
                            lineHeight: {
                                base: "1.555625rem",
                                md: "1.555625rem"
                            },
                            maxWidth: {
                                base: "100%",
                                md: "50%"
                            },
                            mt: "1.25rem",
                            children: "Join our free communities made up of designers passionate about Design and Tech and leveraging it to solve problems."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Button, {
                            background: "transparent",
                            border: "1px solid #FDE85C",
                            color: "brand.yellow.300",
                            mt: "1.25rem",
                            children: [
                                "Join Now",
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    ml: "0.6875rem",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineRightCircle, {})
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./constant/eventPlaybeck.tsx
const eventPlayBack = [
    {
        imageSrc: "assets/images/events/event1.jpg",
        link: "https://youtu.be/q0-y8LvzmE8"
    },
    {
        imageSrc: "assets/images/events/event2.jpg",
        link: "https://youtu.be/jVSv0-u1_j4"
    },
    {
        imageSrc: "assets/images/events/event3.jpg",
        link: "https://youtu.be/ZjuQg53CaeA"
    },
    {
        imageSrc: "assets/images/events/event4.jpg",
        link: "https://youtu.be/lJm0InPnY3I"
    },
    {
        imageSrc: "assets/images/events/event5.jpg",
        link: "https://youtu.be/90nYxxmBmFE"
    },
    {
        imageSrc: "assets/images/events/event6.jpg",
        link: "https://youtu.be/VE6cm5zeTt8"
    }
];

// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./features/events/EventCard.tsx




const EventCard = ({ imageSrc , link , index  })=>{
    const [isHover, setIsHover] = external_react_default().useState(false);
    (0,external_react_.useEffect)(()=>{
        if (index === 0) {
            setIsHover(true);
        }
    }, [
        index
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
        onMouseEnter: ()=>setIsHover(true),
        onMouseLeave: ()=>setIsHover(false),
        href: link,
        target: "_blank",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
            w: {
                base: "20rem",
                md: "100%",
                lg: "100%"
            },
            h: "100%",
            position: "relative",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                    src: imageSrc,
                    alt: "event"
                }),
                isHover && /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                    pos: "absolute",
                    top: "0",
                    left: "0",
                    w: "full",
                    h: "full",
                    bg: "rgba(15, 0, 38, 0.78)",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                        as: bs_.BsFillPlayCircleFill,
                        color: "brand.yellow.500",
                        fontSize: "2.5rem"
                    })
                })
            ]
        })
    }, imageSrc);
};

;// CONCATENATED MODULE: ./features/events/EventPlayback.tsx









external_gsap_default().registerPlugin((ScrollTrigger_default()));
const EventPlayback = ()=>{
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            external_gsap_default().from(".eventPlayback", {
                opacity: "0",
                y: 200,
                duration: 1,
                delay: 1,
                scrollTrigger: {
                    trigger: ".eventPlayback",
                    start: "-900 top",
                    end: "bottom bottom"
                }
            });
        });
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        className: "eventPlayback",
        my: "3rem",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layouts/* MainContainer */.t, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                        w: {
                            base: "100%",
                            md: "50%"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                            subTitle: "our past events",
                            title: "Run a Play back on our Past Sessions.",
                            paragraph: ""
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                    overflow: {
                        base: "scroll",
                        md: "scroll",
                        lg: "hidden"
                    },
                    pb: "2.3075rem",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Grid, {
                        templateColumns: {
                            base: "repeat(6, 1fr)",
                            md: "repeat(3, 1fr)",
                            lg: "repeat(3, 1fr)"
                        },
                        gap: [
                            4,
                            6,
                            6
                        ],
                        children: eventPlayBack.map(({ imageSrc , link  }, index)=>/*#__PURE__*/ jsx_runtime_.jsx(EventCard, {
                                index: index,
                                imageSrc: imageSrc,
                                link: link
                            }, imageSrc))
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./features/events/EventTwitter.tsx







external_gsap_default().registerPlugin((ScrollTrigger_default()));
const EventTwitter = ()=>{
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            external_gsap_default().from(".event-twitter", {
                opacity: "0",
                y: 200,
                duration: 1,
                delay: 1,
                scrollTrigger: {
                    trigger: ".event-twitter",
                    start: "-900 top",
                    end: "bottom bottom"
                }
            });
        });
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        className: "event-twitter",
        children: /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                bg: {
                    base: `linear-gradient(360deg, #352A6C 23.68%, rgba(53, 42, 108, 0) 106.41%),url(assets/images/events/twittermobile.png) center/cover no-repeat`,
                    lg: `linear-gradient(90deg, #34296B 47.57%, rgba(52, 41, 107, 0) 140.52%),url(assets/images/events/twitterevent.png) center/cover no-repeat`
                },
                w: "full",
                h: {
                    base: "auto",
                    lg: "29.5rem"
                },
                position: "relative",
                borderRadius: "1.875rem",
                p: {
                    base: "10.3125rem 1.25rem 2.1875rem 1.25rem",
                    lg: "8.3125rem 5.3125rem"
                },
                my: {
                    base: "1.25rem",
                    lg: "2.5rem"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                            color: "brand.white",
                            fontSize: {
                                base: "1.705rem",
                                md: "3.125rem"
                            },
                            fontWeight: "bold",
                            children: "Join Our Twitter Spaces."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Text, {
                            color: "brand.white",
                            fontSize: {
                                base: "1.125rem",
                                md: "1.125rem"
                            },
                            lineHeight: {
                                base: "1.555625rem",
                                md: "1.555625rem"
                            },
                            maxWidth: {
                                base: "100%",
                                md: "50%"
                            },
                            mt: "1.25rem",
                            children: [
                                "We host twitter spaces every",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Text, {
                                    as: "span",
                                    fontWeight: "bold",
                                    textTransform: "uppercase",
                                    children: [
                                        " ",
                                        "wednesday",
                                        " "
                                    ]
                                }),
                                "to discuss trending topics. Follow us on Twitter and get notified everytime."
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Button, {
                            background: "transparent",
                            border: "1px solid #FDE85C",
                            color: "brand.yellow.300",
                            mt: "1.25rem",
                            fontSize: {
                                base: "1.125rem",
                                md: "1.125rem"
                            },
                            p: {
                                base: "0.625rem 1.25rem",
                                md: "1.25rem 1.3125em"
                            },
                            as: react_.Link,
                            href: "https://twitter.com/perxels",
                            target: "_blank",
                            children: [
                                "Follow Us on Twitter",
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    ml: "0.6875rem",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineRightCircle, {})
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./features/events/index.ts








/***/ }),

/***/ 1028:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "b": () => (/* reexport */ PastSpeakers),
  "z": () => (/* reexport */ SpeakerHero)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "gsap"
var external_gsap_ = __webpack_require__(4287);
var external_gsap_default = /*#__PURE__*/__webpack_require__.n(external_gsap_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
// EXTERNAL MODULE: ./components/index.ts + 9 modules
var components = __webpack_require__(6520);
;// CONCATENATED MODULE: ./features/speakers/SpeakerForm.tsx




const SpeakerForm = ()=>{
    const scriptUrl = "https://script.google.com/macros/s/AKfycbz05WPBUPRhMgIHjoiKlRfEWpY6SUHbD49EbtHu0Q2XX6amBh9jKkNN4vC0c3qo__45Pw/exec";
    const { isOpen , onOpen , onClose  } = (0,react_.useDisclosure)();
    const handleSubmit = (e)=>{
        e.preventDefault();
        const inputData = e.target;
        const formData = new FormData();
        formData.append("fullname", inputData.fullname.value);
        formData.append("email", inputData.email.value);
        formData.append("topic", inputData.topic.value);
        formData.append("aboutspeaker", inputData.aboutspeaker.value);
        //current date and time
        formData.append("created_at", new Date().toLocaleString());
        fetch(scriptUrl, {
            method: "POST",
            body: formData
        }).then((response)=>{
            if (response.status === 201 || 200) {
                onOpen();
            } else {}
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* SuccessModal */.i_, {
                isOpen: isOpen,
                onClose: onClose,
                title: "Thank you for choosing to be a speaker.",
                description: "An email would be sent to you shortly"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                as: "form",
                bg: "brand.gray.300",
                px: [
                    "1.5rem",
                    "1.5rem",
                    "1.5rem",
                    "2.5rem"
                ],
                py: [
                    "1.5rem",
                    "1.5rem",
                    "1.5rem",
                    "3.5rem"
                ],
                rounded: "10px",
                onSubmit: handleSubmit,
                className: "speaker-form",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                    spacing: "1.75rem",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Input, {
                            h: "3.5rem",
                            bg: "brand.white",
                            placeholder: "Full Name*",
                            name: "fullname",
                            isRequired: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Input, {
                            h: "3.5rem",
                            bg: "brand.white",
                            type: "email",
                            placeholder: "Email Address*",
                            name: "email",
                            isRequired: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Input, {
                            h: "3.5rem",
                            bg: "brand.white",
                            placeholder: "Your Topic*",
                            name: "topic",
                            isRequired: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Textarea, {
                            h: "10.25rem",
                            bg: "brand.white",
                            pt: "1.05rem",
                            placeholder: "Tell us a little about yourself",
                            name: "aboutspeaker",
                            isRequired: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                            w: "full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                h: [
                                    "3rem",
                                    "3rem",
                                    "3rem",
                                    "3.75rem"
                                ],
                                w: [
                                    "full",
                                    "full",
                                    "full",
                                    "19.5rem"
                                ],
                                type: "submit",
                                children: "Submit"
                            })
                        })
                    ]
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./features/speakers/SpeakerHero.tsx






const SpeakerHero = ()=>{
    const mainRef = (0,external_react_.useRef)(null);
    const tl = (0,external_react_.useRef)(external_gsap_default().timeline({
        paused: true
    }));
    (0,external_react_.useEffect)(()=>{
        let ctx = external_gsap_default().context(()=>{
            tl.current.from(mainRef, {
                background: "#fff",
                duration: 0.5,
                delay: 0.5
            }).from(".speaker-top", {
                opacity: 0,
                y: 100,
                duration: 0.5
            }).from(".blue-pattern", {
                opacity: 0,
                duration: 0.5
            }).from(".speaker-heading", {
                opacity: 0,
                y: 100,
                duration: 0.75
            }).from(".speaker-desc", {
                opacity: 0,
                y: 100,
                duration: 0.75
            }).from(".speaker-bottom", {
                opacity: 0,
                y: 100,
                duration: 0.75
            }).from(".pattern5", {
                opacity: 0,
                duration: 0.75
            }).play();
            external_gsap_default().from(".speaker-form", {
                opacity: 0,
                scale: 0,
                duration: 1,
                delay: 0.75
            });
        }, mainRef);
        return ()=>ctx.revert();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        backgroundImage: [
            "",
            "url('/assets/images/speakers/hero.svg')"
        ],
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        ref: mainRef,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
                bg: "none",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
                    columns: [
                        1,
                        1,
                        1,
                        2
                    ],
                    gap: "2rem",
                    py: "4rem",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                            pt: [
                                "2rem",
                                "2rem",
                                "2rem",
                                "0"
                            ],
                            pb: [
                                "4rem",
                                "4rem",
                                "4rem",
                                "0"
                            ],
                            justifyContent: "center",
                            position: "relative",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                    src: "/assets/images/speakers/speaker-top.png",
                                    w: "3rem",
                                    h: "auto",
                                    alt: "pattern",
                                    pos: "absolute",
                                    top: "-2rem",
                                    left: "-2rem",
                                    className: "speaker-top"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                    src: "/assets/images/speakers/blue.svg",
                                    w: "1.5rem",
                                    h: "auto",
                                    alt: "pattern",
                                    pos: "absolute",
                                    top: "-2rem",
                                    left: "16rem",
                                    className: "blue-pattern"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                    src: "/assets/images/speakers/pattern5.svg",
                                    w: [
                                        "2rem",
                                        "2rem",
                                        "2rem",
                                        "3rem"
                                    ],
                                    h: "auto",
                                    alt: "pattern",
                                    pos: "absolute",
                                    bottom: [
                                        "1rem",
                                        "1rem",
                                        "1rem",
                                        "3rem"
                                    ],
                                    left: "0",
                                    className: "pattern5"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                    src: "/assets/images/speakers/speaker-bottom.png",
                                    w: "3rem",
                                    h: "auto",
                                    alt: "pattern",
                                    pos: "absolute",
                                    bottom: [
                                        "-1rem",
                                        "-1rem",
                                        "-1rem",
                                        "-2rem"
                                    ],
                                    left: "12rem",
                                    className: "speaker-bottom"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Heading, {
                                    className: "speaker-heading",
                                    as: "h1",
                                    fontSize: [
                                        "6xl",
                                        "6xl",
                                        "7xl",
                                        "8xl"
                                    ],
                                    pr: [
                                        "2rem",
                                        "2rem",
                                        "2rem",
                                        "0"
                                    ],
                                    color: "brand.dark.200",
                                    children: [
                                        "Thank you for accepting to speak at our",
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                            as: "span",
                                            color: "brand.pink.700",
                                            children: "AMA Session"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    className: "speaker-desc",
                                    fontSize: [
                                        "xl",
                                        "xl",
                                        "xl",
                                        "3xl"
                                    ],
                                    color: "brand.dark.200",
                                    children: "You have the knowledge and the expertise, we have the platform. Join us up-skill the next generation of tech talents.."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(SpeakerForm, {})
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                src: "/assets/images/speakers/bottomPattern.png",
                w: [
                    "auto",
                    "auto",
                    "auto",
                    "full"
                ],
                h: [
                    "3rem",
                    "3rem",
                    "3rem",
                    "auto"
                ],
                alt: "bottom pattern",
                objectFit: "cover"
            })
        ]
    });
};

// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./features/speakers/PastSpeakers.tsx






const sliderData = [
    {
        id: 1,
        img: "/assets/images/speakers/speaker1.jpg",
        name: "Nandi Manning",
        title: "Senior XDR @ Intuit Mailchimp"
    },
    {
        id: 2,
        img: "/assets/images/speakers/speaker2.jpg",
        name: "Chidinma Ukaegbu",
        title: "Product Designer @ MyCover.ai"
    },
    {
        id: 3,
        img: "/assets/images/speakers/speaker3.jpg",
        name: "Bryan Benibo",
        title: "Saas Marketing Designer"
    },
    {
        id: 4,
        img: "/assets/images/speakers/speaker4.jpg",
        name: "Jadesola Odujole",
        title: "Content Designer @ chippercash"
    },
    {
        id: 5,
        img: "/assets/images/speakers/speaker5.jpg",
        name: "James Baduor",
        title: "Cofounder ADPList"
    },
    {
        id: 6,
        img: "/assets/images/speakers/speaker6.jpg",
        name: "Ayomide Mobolaji",
        title: "Product Designer KUUMBA"
    },
    {
        id: 7,
        img: "/assets/images/speakers/speaker7.jpg",
        name: "Sebiomo",
        title: "Head of Design @ VoyanceHQ"
    },
    {
        id: 8,
        img: "/assets/images/speakers/speaker8.jpg",
        name: "Abiodun-Fiwa",
        title: "CEO, Perxels"
    }
];
const PastSpeakers = ()=>{
    const settings = {
        dots: false,
        arrows: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        cssEase: "linear",
        responsive: [
            {
                breakpoint: 1460,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    initialSlide: 4
                }
            },
            {
                breakpoint: 900,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        pb: "4rem",
        pt: "3rem",
        bg: "brand.gray.300",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
                bg: "none",
                children: /*#__PURE__*/ jsx_runtime_.jsx(components/* SectionHeader */.M$, {
                    subTitle: "Past Speakers",
                    title: "Meet the experts that have come to share their knowledge."
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                pos: "relative",
                overflow: "hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                    ...settings,
                    children: sliderData.map(({ id , img , name , title  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                            px: "0.75rem",
                            overflowX: "hidden",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                    rounded: "5px",
                                    src: img,
                                    alt: name,
                                    w: "full",
                                    h: "auto"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                                    gap: "0.5rem",
                                    mt: "1rem",
                                    alignItems: "center",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                                            fontSize: "sm",
                                            color: "brand.dark.200",
                                            children: name
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                            fontSize: "sm",
                                            color: "brand.dark.200",
                                            children: "|"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                            fontSize: "sm",
                                            color: "brand.dark.200",
                                            children: title
                                        })
                                    ]
                                })
                            ]
                        }, id))
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./features/speakers/index.ts




/***/ })

};
;