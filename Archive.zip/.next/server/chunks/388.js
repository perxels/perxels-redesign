"use strict";
exports.id = 388;
exports.ids = [388];
exports.modules = {

/***/ 6520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Oo": () => (/* reexport */ components_BgHeader),
  "$_": () => (/* reexport */ components_Footer),
  "h4": () => (/* reexport */ components_Header),
  "lk": () => (/* reexport */ ListWrapper),
  "TR": () => (/* reexport */ components_Logo),
  "M$": () => (/* reexport */ components_SectionHeader),
  "J0": () => (/* reexport */ components_StoryIcon),
  "i_": () => (/* reexport */ components_SuccessModal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: ./components/Logo.tsx



function Logo({ color , width , height  }) {
    const [isLargerThan800] = (0,react_.useMediaQuery)("(min-width: 800px)");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: width || isLargerThan800 ? "109" : "116.8",
        height: height || isLargerThan800 ? "29.86" : "32",
        fill: "none",
        viewBox: "0 0 146 40",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: color || "#34296B",
                d: "M33.378 31.765V8.735H44.16c1.215 0 2.318.196 3.308.59 1 .393 1.816.927 2.446 1.601a6.907 6.907 0 011.468 2.36c.349.888.523 1.844.523 2.867a7.726 7.726 0 01-.523 2.849 7.128 7.128 0 01-1.468 2.36c-.641.675-1.457 1.208-2.447 1.602-.99.393-2.092.59-3.307.59H38.29v8.21h-4.91zm4.91-12.527h5.18c.99 0 1.806-.281 2.447-.843.653-.562.979-1.31.979-2.242 0-.945-.326-1.698-.979-2.26-.641-.562-1.457-.843-2.447-.843h-5.18v6.188zm15.524 4.164c0-1.607.365-3.074 1.097-4.4a8.153 8.153 0 013.087-3.153c1.328-.787 2.813-1.18 4.455-1.18 2.497 0 4.51.849 6.04 2.546 1.541 1.686 2.312 3.889 2.312 6.609v1.028H58.401c.158 1.08.658 1.973 1.502 2.68.844.709 1.946 1.063 3.307 1.063.743 0 1.536-.146 2.38-.438.854-.304 1.535-.703 2.041-1.197l1.957 2.9c-.81.741-1.828 1.314-3.054 1.72a11.989 11.989 0 01-3.813.606c-2.576 0-4.708-.804-6.395-2.41-1.676-1.62-2.514-3.744-2.514-6.374zm4.556-1.585h8.217a3.877 3.877 0 00-.304-1.23 4.276 4.276 0 00-.726-1.13c-.303-.36-.725-.646-1.265-.86-.54-.225-1.153-.337-1.84-.337-.652 0-1.237.107-1.754.32-.517.214-.934.5-1.249.86a4.263 4.263 0 00-.742 1.13c-.18.393-.292.809-.337 1.247zm15.607 9.948V15.09h4.387v2.243c.641-.765 1.44-1.4 2.396-1.905.968-.506 1.946-.76 2.936-.76v4.283c-.303-.067-.709-.1-1.215-.1-.742 0-1.524.19-2.345.572-.821.371-1.412.815-1.772 1.332v11.01h-4.387zm10.276 0l5.94-8.565-5.603-8.11h4.91l3.46 5.109 3.425-5.109h4.91l-5.568 8.11 5.939 8.565h-4.91l-3.797-5.631-3.83 5.63h-4.876zm18.527-8.363c0-1.607.365-3.074 1.096-4.4a8.162 8.162 0 013.088-3.153c1.328-.787 2.812-1.18 4.455-1.18 2.497 0 4.511.849 6.04 2.546 1.541 1.686 2.311 3.889 2.311 6.609v1.028h-12.401a4.183 4.183 0 001.502 2.68c.844.709 1.946 1.063 3.307 1.063.742 0 1.535-.146 2.379-.438.855-.304 1.536-.703 2.042-1.197l1.957 2.9c-.81.741-1.828 1.314-3.054 1.72a11.989 11.989 0 01-3.813.606c-2.576 0-4.708-.804-6.395-2.41-1.676-1.62-2.514-3.744-2.514-6.374zm4.555-1.585h8.218a3.877 3.877 0 00-.304-1.23 4.286 4.286 0 00-.726-1.13c-.303-.36-.725-.646-1.265-.86-.54-.225-1.153-.337-1.839-.337-.653 0-1.238.107-1.755.32-.517.214-.934.5-1.249.86a4.262 4.262 0 00-.742 1.13c-.18.393-.293.809-.338 1.247zm15.609 9.948V8.735h4.387v23.03h-4.387zm7.288-2.175l1.907-3.17c.652.618 1.524 1.158 2.615 1.618 1.102.461 2.155.692 3.156.692.922 0 1.62-.158 2.092-.472.472-.326.709-.759.709-1.298 0-.36-.186-.658-.557-.894-.36-.236-.833-.421-1.418-.556a33.934 33.934 0 00-1.924-.388 18.72 18.72 0 01-2.108-.54 9.359 9.359 0 01-1.924-.86c-.574-.348-1.046-.842-1.417-1.483-.36-.652-.54-1.422-.54-2.31 0-1.472.607-2.714 1.822-3.726 1.216-1.023 2.885-1.534 5.012-1.534 2.564 0 4.802.759 6.716 2.276l-1.772 3.119c-.529-.55-1.244-1.012-2.143-1.383a7.204 7.204 0 00-2.801-.556c-.788 0-1.424.152-1.907.455-.473.304-.708.692-.708 1.164 0 .292.14.54.421.741.281.192.652.343 1.114.456.472.1 1.001.219 1.586.354.596.135 1.203.27 1.822.404.63.124 1.237.326 1.822.607.597.27 1.126.585 1.586.944.473.36.85.849 1.131 1.467.281.619.422 1.332.422 2.141 0 1.574-.648 2.855-1.94 3.844-1.283.99-3.055 1.484-5.315 1.484-1.452 0-2.841-.23-4.168-.691-1.317-.461-2.413-1.096-3.291-1.905z"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: color || "#34296B",
                fillRule: "evenodd",
                d: "M10.765 22.575v11.332h-1.45v1.56H1.45v-1.56H0V8.944h15.697v1.505h2.45v2.12h1.934v6.738h-1.934v1.765h-2.45v1.504h-4.932z",
                clipRule: "evenodd"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: color || "#34296B",
                fillRule: "evenodd",
                d: "M21.158 7.557V4.375H17.44v-.846H4.382v3.115H17.44v.926h2.377v3.238h3.508v-3.25h-2.167z",
                clipRule: "evenodd"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: color || "#34296B",
                d: "M10.765 22.575v11.332h-1.45v1.56H1.45v-1.56H0V8.944h15.697v1.505h2.45v2.12h1.934v6.738h-1.934v1.765h-2.45v1.504h-4.932z"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: color || "#34296B",
                d: "M21.158 7.557V4.375H17.44v-.846H4.382v3.115H17.44v.926h2.377v3.238h3.508v-3.25h-2.167z"
            })
        ]
    });
}
/* harmony default export */ const components_Logo = (Logo);

// EXTERNAL MODULE: ./constant/index.ts + 9 modules
var constant = __webpack_require__(230);
// EXTERNAL MODULE: ./layouts/index.ts + 2 modules
var layouts = __webpack_require__(5329);
;// CONCATENATED MODULE: ./components/Footer.tsx






const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
        bg: "brand.dark.200",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
            py: "1.875rem",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                    bg: "brand.purple.500",
                    px: "3rem",
                    py: "1.5rem",
                    borderRadius: "10px",
                    alignItems: "center",
                    justifyContent: "space-between",
                    display: [
                        "none",
                        "none",
                        "none",
                        "flex"
                    ],
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                            fontSize: "4xl",
                            color: "brand.white",
                            fontWeight: "bold",
                            children: "Want to transition into Design?"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                            as: react_.Link,
                            href: "/class-plans",
                            _hover: {
                                textDecor: "none",
                                bg: "brand.yellow.500"
                            },
                            bg: "brand.white",
                            color: "brand.purple.500",
                            children: "Enroll Now"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Grid, {
                    display: [
                        "none",
                        "none",
                        "none",
                        "grid"
                    ],
                    mt: "4.125rem",
                    templateColumns: "repeat(6, 1fr)",
                    gap: 6,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.GridItem, {
                            colSpan: 3,
                            w: "100%",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(components_Logo, {
                                    color: "white"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    mt: "0.75rem",
                                    color: "brand.white",
                                    fontSize: "0.875rem",
                                    lineHeight: "1.5rem",
                                    fontWeight: "400",
                                    maxW: "366px",
                                    children: "At Perxels, our primary aim is to equip you with core design skills and soft skills needed to become a more proficient designer, navigate through the job market and advance in your career."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                                    alignItems: "center",
                                    gap: "0.75rem",
                                    mt: "1.875rem",
                                    children: constant/* FooterSocialLinks.map */.hA.map(({ name , url , icon  })=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: url,
                                            target: "_blank",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                                                w: "1.875rem",
                                                h: "1.875rem",
                                                bg: "brand.white",
                                                rounded: "full",
                                                _hover: {
                                                    bg: "brand.yellow.500"
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                                    as: icon,
                                                    w: "0.875rem",
                                                    h: "0.875rem",
                                                    fontSize: "0.875rem",
                                                    color: "brand.purple.500"
                                                })
                                            })
                                        }, name))
                                })
                            ]
                        }),
                        constant/* links.map */.Ok.map(({ title , links  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.GridItem, {
                                colSpan: 1,
                                w: "100%",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        color: "brand.white",
                                        fontSize: "1.125rem",
                                        fontWeight: "bold",
                                        children: title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(react_.VStack, {
                                        mt: "1.5rem",
                                        spacing: "1.25rem",
                                        children: links.map(({ name , url  })=>/*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                                target: name === "Community" ? "_blank" : "_self",
                                                w: "full",
                                                href: url,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                    w: "full",
                                                    textAlign: "left",
                                                    fontSize: "0.875rem",
                                                    color: "brand.white",
                                                    _hover: {
                                                        color: "brand.yellow.500"
                                                    },
                                                    children: name
                                                })
                                            }, name))
                                    })
                                ]
                            }, title))
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                    display: [
                        "flex",
                        "flex",
                        "flex",
                        "none"
                    ],
                    alignItems: "flex-start",
                    spacing: "1.25rem",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Heading, {
                            textAlign: "left",
                            fontSize: [
                                "4xl",
                                "5xl"
                            ],
                            maxW: "300px",
                            color: "brand.white",
                            children: [
                                "Equipping designers to",
                                " ",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
                                    as: "span",
                                    color: "brand.yellow.500",
                                    children: [
                                        " ",
                                        "solve problems"
                                    ]
                                }),
                                " ",
                                "with design."
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                            mt: "1.5rem",
                            display: [
                                "block",
                                "block",
                                "block",
                                "none"
                            ],
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                bg: "brand.yellow.500",
                                color: "brand.purple.500",
                                as: react_.Link,
                                href: "/class-plans",
                                children: "Get Started"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.SimpleGrid, {
                    display: [
                        "grid",
                        "grid",
                        "grid",
                        "none"
                    ],
                    mt: "2.5rem",
                    columns: 1,
                    gap: "1rem",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                            alignItems: "flex-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    fontSize: "1rem",
                                    fontWeight: "400",
                                    color: "#aaa",
                                    textTransform: "uppercase",
                                    textAlign: "left",
                                    children: "Contact"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                    w: "full",
                                    target: "_blank",
                                    href: "mailto: perxels@gmail.com",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        w: "full",
                                        fontSize: [
                                            "lg",
                                            "xl",
                                            "2xl"
                                        ],
                                        textAlign: "left",
                                        color: "brand.white",
                                        _hover: {
                                            color: "brand.yellow.500"
                                        },
                                        children: "perxels@gmail.com"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                    w: "full",
                                    target: "_blank",
                                    href: "tel: +2348135369680",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        w: "full",
                                        fontSize: [
                                            "lg",
                                            "xl",
                                            "2xl"
                                        ],
                                        textAlign: "left",
                                        color: "brand.white",
                                        _hover: {
                                            color: "brand.yellow.500"
                                        },
                                        children: "+2348135369680"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                            alignItems: "flex-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    fontSize: "1rem",
                                    fontWeight: "400",
                                    color: "#aaa",
                                    textTransform: "uppercase",
                                    textAlign: "left",
                                    children: "Pages"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                    w: "full",
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        w: "full",
                                        fontSize: [
                                            "lg",
                                            "xl",
                                            "2xl"
                                        ],
                                        textAlign: "left",
                                        color: "brand.white",
                                        _hover: {
                                            color: "brand.yellow.500"
                                        },
                                        children: "Home"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                    w: "full",
                                    href: "/testimonials",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        w: "full",
                                        fontSize: [
                                            "lg",
                                            "xl",
                                            "2xl"
                                        ],
                                        textAlign: "left",
                                        color: "brand.white",
                                        _hover: {
                                            color: "brand.yellow.500"
                                        },
                                        children: "Testimonials"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                    w: "full",
                                    href: "/class-plans",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        w: "full",
                                        fontSize: [
                                            "lg",
                                            "xl",
                                            "2xl"
                                        ],
                                        textAlign: "left",
                                        color: "brand.white",
                                        _hover: {
                                            color: "brand.yellow.500"
                                        },
                                        children: "Enroll now"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                                    w: "full",
                                    href: "/class-plans",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                        w: "full",
                                        fontSize: [
                                            "lg",
                                            "xl",
                                            "2xl"
                                        ],
                                        textAlign: "left",
                                        color: "brand.white",
                                        _hover: {
                                            color: "brand.yellow.500"
                                        },
                                        children: "Class Plans"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.VStack, {
                    display: [
                        "flex",
                        "flex",
                        "flex",
                        "none"
                    ],
                    alignItems: "flex-start",
                    mt: "1.5rem",
                    spacing: "1.5rem",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Flex, {
                            alignItems: "center",
                            gap: "0.75rem",
                            mt: "1.875rem",
                            children: constant/* FooterSocialLinks.map */.hA.map(({ name , url , icon  })=>{
                                if (name !== "WhatsApp") {
                                    return /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: url,
                                        target: "_blank",
                                        rel: "noreferrer",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                                            w: "1.875rem",
                                            h: "1.875rem",
                                            bg: "brand.white",
                                            rounded: "full",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                                                as: icon,
                                                w: "0.875rem",
                                                h: "0.875rem",
                                                fontSize: "0.875rem",
                                                color: "brand.purple.500"
                                            })
                                        })
                                    }, name);
                                }
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(components_Logo, {
                            color: "white",
                            width: "107px",
                            height: "29.32px"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                    textAlign: "left",
                    fontSize: "lg",
                    mt: [
                        "3.125rem",
                        "3.125rem",
                        "5rem"
                    ],
                    mb: "1.5rem",
                    color: "brand.white",
                    children: "\xa9 Perxels 2022, All Rights Reserved."
                })
            ]
        })
    });
};
/* harmony default export */ const components_Footer = (Footer);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
;// CONCATENATED MODULE: ./components/HeaderDropdown.tsx




const HeaderDropdown = ({ setShowDropdown  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
        w: "full",
        h: "calc(100vh - 4rem)",
        bg: "brand.white",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
            alignItems: "center",
            gap: "4.375rem",
            flexDir: "column",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    onClick: ()=>setShowDropdown(false),
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                        fontSize: "xl",
                        children: "Home"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    onClick: ()=>setShowDropdown(false),
                    href: "/testimonials",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                        fontSize: "xl",
                        children: "Testimonials"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    onClick: ()=>setShowDropdown(false),
                    href: "/student-works",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                        fontSize: "xl",
                        children: "Student Projects"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    onClick: ()=>setShowDropdown(false),
                    href: "/events",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                        fontSize: "xl",
                        children: "Events"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    onClick: ()=>setShowDropdown(false),
                    href: "/partners",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                        fontSize: "xl",
                        children: "Be a Partner"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    onClick: ()=>setShowDropdown(false),
                    href: "/class-plans",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                        children: "View Class Plans"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_HeaderDropdown = (HeaderDropdown);

;// CONCATENATED MODULE: ./components/Header.tsx









const Header = ({ isDark =false  })=>{
    const [showDropdown, setShowDropdown] = external_react_default().useState(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        pos: "sticky",
        top: "0",
        zIndex: "5",
        bg: isDark ? "brand.dark.200" : "brand.white",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(layouts/* MainContainer */.t, {
                bg: "none",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                    alignItems: "center",
                    justifyContent: "space-between",
                    py: "1.25rem",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                            alignItems: "center",
                            gap: "6.875rem",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_Logo, {
                                        color: isDark ? "#FDE85C" : "#34296B"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Flex, {
                                    display: [
                                        "none",
                                        "none",
                                        "none",
                                        "flex"
                                    ],
                                    alignItems: "center",
                                    gap: "4.375rem",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/testimonials",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                color: isDark ? "brand.white" : "brand.primary.500",
                                                _hover: {
                                                    color: "brand.yellow.500"
                                                },
                                                fontSize: "xl",
                                                children: "Testimonials"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/student-works",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                color: isDark ? "brand.white" : "brand.primary.500",
                                                _hover: {
                                                    color: "brand.yellow.500"
                                                },
                                                fontSize: "xl",
                                                children: "Student Projects"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/events",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                color: isDark ? "brand.white" : "brand.primary.500",
                                                _hover: {
                                                    color: "brand.yellow.500"
                                                },
                                                fontSize: "xl",
                                                children: "Events"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/partners",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                                color: isDark ? "brand.white" : "brand.primary.500",
                                                _hover: {
                                                    color: "brand.yellow.500"
                                                },
                                                fontSize: "xl",
                                                children: "Be a Partner"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/class-plans",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                h: "3.125rem",
                                variant: isDark ? "solid-white" : "solid",
                                display: [
                                    "none",
                                    "none",
                                    "none",
                                    "flex"
                                ],
                                px: "2.25rem",
                                children: "View Class Plans"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(react_.Icon, {
                            as: !showDropdown ? ri_.RiMenu3Line : io5_.IoCloseSharp,
                            fontSize: "1.875rem",
                            color: isDark ? "brand.white" : "brand.primary.500",
                            cursor: "pointer",
                            display: [
                                "block",
                                "block",
                                "block",
                                "none"
                            ],
                            onClick: ()=>setShowDropdown(!showDropdown)
                        })
                    ]
                })
            }),
            showDropdown && /*#__PURE__*/ jsx_runtime_.jsx(components_HeaderDropdown, {
                setShowDropdown: setShowDropdown
            })
        ]
    });
};
/* harmony default export */ const components_Header = (Header);

;// CONCATENATED MODULE: ./components/SectionHeader.tsx



const SectionHeader = ({ subTitle , title , paragraph , isWhite , isArrow , arrowLeftPos , arrowTopPos , arrowRightPos , arrowRightBottomPos , maxW , headingSize , headingColor  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        pos: "relative",
        mb: "2.375rem",
        children: [
            isArrow ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                        src: "/assets/icons/arrow-left-down.svg",
                        pos: "absolute",
                        width: "12rem",
                        height: "auto",
                        top: arrowTopPos || "0",
                        left: arrowLeftPos || "0",
                        display: [
                            "none",
                            "none",
                            "none",
                            "block"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                        src: "/assets/icons/arrow-right-down.svg",
                        pos: "absolute",
                        width: "12rem",
                        height: "auto",
                        top: arrowRightBottomPos || "-4rem",
                        right: arrowRightPos || "10rem",
                        display: [
                            "none",
                            "none",
                            "none",
                            "block"
                        ]
                    })
                ]
            }) : null,
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                    as: "span",
                    py: "0.75rem",
                    px: "0.688rem",
                    bg: "brand.yellow.300",
                    fontSize: [
                        "xs",
                        "xs",
                        "xl"
                    ],
                    fontWeight: "bold",
                    textTransform: "uppercase",
                    rounded: "10px",
                    children: subTitle
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Heading, {
                color: isWhite ? "brand.white" : headingColor ? headingColor : "brand.purple.500",
                textAlign: "center",
                fontSize: headingSize || [
                    "2rem",
                    "2rem",
                    "7xl"
                ],
                maxW: maxW || "auto",
                m: "0 auto",
                mb: "1rem",
                mt: "1.25rem",
                children: title
            }),
            paragraph && /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                textAlign: "center",
                fontSize: [
                    "0.9rem",
                    "0.9rem",
                    "1.375rem"
                ],
                lineHeight: "1.5",
                maxW: "669px",
                color: "brand.dark.100",
                m: "0 auto",
                dangerouslySetInnerHTML: {
                    __html: paragraph
                }
            })
        ]
    });
};
/* harmony default export */ const components_SectionHeader = (SectionHeader);

;// CONCATENATED MODULE: ./components/BgHeader.tsx



const BgHeader = ({ bg ="brand.purple.500" , color ="brand.white" , children  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
            as: "span",
            bg: bg,
            color: color,
            fontSize: "2xl",
            fontWeight: "bold",
            textTransform: "uppercase",
            p: "0.75rem",
            rounded: "10px",
            children: children
        })
    });
};
/* harmony default export */ const components_BgHeader = (BgHeader);

;// CONCATENATED MODULE: ./components/List.tsx



const ListWrapper = ({ lists , bg ="brand.purple.500" , color ="brand.dark.200"  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.List, {
        spacing: "1.25rem",
        children: lists.map((list)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.ListItem, {
                alignItems: "center",
                gap: "1.25rem",
                fontSize: "1.25rem",
                fontWeight: "light",
                color: color,
                display: "grid",
                gridTemplateColumns: "1.25rem 1fr",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                        w: "1.25rem",
                        h: "1.25rem",
                        bg: bg,
                        rounded: "3px"
                    }),
                    " ",
                    list
                ]
            }, list))
    });
};

;// CONCATENATED MODULE: ./components/StoryIcon.tsx


const StoryIcon = ({ circleColor , pathColor , size  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: size ?? "100",
        height: size ?? "101",
        fill: "none",
        viewBox: "0 0 100 101",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                cx: "50",
                cy: "50.13",
                r: "50",
                fill: circleColor ?? "#fff"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                clipPath: "url(#clip0_121_4)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    fill: pathColor ?? "#34296B",
                    d: "M52.56 27.12l.002 6.491A16.968 16.968 0 0167.27 48.32h6.491v4.24l-6.491.002a16.97 16.97 0 01-14.707 14.706l-.002 6.492h-4.24v-6.492a16.969 16.969 0 01-14.709-14.706l-6.491-.002v-4.24h6.491A16.968 16.968 0 0148.32 33.61V27.12h4.24zM50.44 46.2a4.24 4.24 0 100 8.479 4.24 4.24 0 000-8.48z"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_121_4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        fill: circleColor ?? "#fff",
                        d: "M0 0H50.88V50.88H0z",
                        transform: "translate(25 25)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const components_StoryIcon = (StoryIcon);

;// CONCATENATED MODULE: ./components/SuccessModal.tsx




const SuccessModal = ({ isOpen , onClose , title , description  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Modal, {
            isOpen: isOpen,
            onClose: onClose,
            size: [
                "xs",
                "xs",
                "xs",
                "xl"
            ],
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react_.ModalOverlay, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(react_.ModalContent, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.ModalBody, {
                        padding: [
                            "1.5rem",
                            "1.5rem",
                            "1.5rem",
                            "2.6875rem 2.3125rem"
                        ],
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.ModalCloseButton, {
                                    backgroundColor: "#121212",
                                    rounded: "50%",
                                    color: "#fff",
                                    fontWeight: "700"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                                    mb: [
                                        "1rem",
                                        "1rem",
                                        "1rem",
                                        "1.4375rem"
                                    ],
                                    boxSize: "9.8125rem",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Img, {
                                        src: "/assets/icons/success.png",
                                        alt: "success"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    textAlign: "center",
                                    fontWeight: "700",
                                    color: "#121212",
                                    fontSize: [
                                        "1rem",
                                        "1.5rem",
                                        "2.135625rem",
                                        "2.135625rem"
                                    ],
                                    lineHeight: [
                                        "1.5rem",
                                        "2.15rem",
                                        "2.603125rem",
                                        "2.500625rem"
                                    ],
                                    children: title
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Text, {
                                    textAlign: "center",
                                    fontWeight: "400",
                                    color: "#121212",
                                    fontSize: [
                                        "1rem",
                                        "1.5rem",
                                        "2.135625rem",
                                        "1.5625rem"
                                    ],
                                    lineHeight: [
                                        "1.5rem",
                                        "2.15rem",
                                        "2.603125rem",
                                        "2.15rem"
                                    ],
                                    mt: [
                                        "1rem",
                                        "1rem",
                                        "1rem",
                                        "0.9375rem"
                                    ],
                                    children: description
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(react_.Center, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                                        mt: [
                                            "1rem",
                                            "1rem",
                                            "1rem",
                                            "1.4375rem"
                                        ],
                                        children: "Back to Home Page"
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_SuccessModal = (SuccessModal);

;// CONCATENATED MODULE: ./components/index.ts











/***/ }),

/***/ 5329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "t": () => (/* reexport */ MainContainer),
  "Z": () => (/* reexport */ MainLayout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./layouts/MainContainer.tsx



const MainContainer = ({ children , bg , h , noMobilePadding  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        bg: bg || "brand.white",
        h: h || "auto",
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Container, {
            px: noMobilePadding ? [
                "0",
                "0",
                "0",
                "1rem"
            ] : "1rem",
            maxW: noMobilePadding ? [
                "100%",
                "100%",
                "100%",
                "container.xl"
            ] : "container.xl",
            children: children
        })
    });
};

// EXTERNAL MODULE: ./components/index.ts + 9 modules
var components = __webpack_require__(6520);
;// CONCATENATED MODULE: ./layouts/MainLayout.tsx



const MainLayout = ({ children , isDark  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Header */.h4, {
                isDark: isDark
            }),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Footer */.$_, {})
        ]
    });
};

;// CONCATENATED MODULE: ./layouts/index.ts




/***/ })

};
;