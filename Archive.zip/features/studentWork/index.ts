import Hero from './Hero'
import StudentWorksWrapper from './StudentWorks'

export { Hero, StudentWorksWrapper }
