import React from 'react'
import { EnrolWrapper } from '../features/register/EnrolWrapper'

const enrol = () => {
  return <EnrolWrapper />
}

export default enrol
