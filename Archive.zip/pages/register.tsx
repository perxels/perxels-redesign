import React from 'react'
import { RegisterWrapper } from '../features/register'

const Register = () => {
  return <RegisterWrapper />
}

export default Register
